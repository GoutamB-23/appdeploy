// import React, { useState } from 'react';
// import UploadFile from './components/Upload/UploadFile';
// import ShareLinks from './components/Display/ShareLinks';
// import './components/Layout/Header';
// import './components/Layout/Footer';
// import Header from './components/Layout/Header';
// import Footer from './components/Layout/Footer';
// import FloatingButtons from './components/FloatingBoard';
// import Layout  from './components/Layout/LayOut';
// import { useTheme } from './context/ThemeContext';
// import { lightTheme, darkTheme } from './theme/theme';
// import { ThemeProvider as MuiThemeProvider } from '@mui/material/styles';
// import CssBaseline from '@mui/material/CssBaseline';


// function App() {
//   const [fileLink, setFileLink] = useState('');
//   const [fileName, setFileName] = useState('');
//   const [isOpen, setIsOpen] = useState(false);
//    const { isDarkMode } = useTheme();


//   const handleFileUpload = async (file) => {
//     // Call service to upload file
//     const uploadedFileUrl = await window.firebaseService.uploadFile(file);
//     setFileLink(uploadedFileUrl);
//     setFileName(file.name);
//   };

//   return (
//     // <div style={{ padding: '20px', textAlign: 'center' }}>
//     //   <Layout />
     
//     //   {/* <h1>File Sharing App</h1>
//     //   <UploadFile onFileUpload={handleFileUpload} />
//     //   {fileLink && <ShareLinks link={fileLink} filename={fileName} />}
//     //   <FloatingButtons  isOpen={isOpen} 
//     //   onClose={() => setIsOpen(false)} /> */}
      
//     // </div>
//       <MuiThemeProvider theme={isDarkMode ? darkTheme : lightTheme}
//       style={{ padding: '20px', textAlign: 'center' }}>
//       <CssBaseline />
//       <Layout />
//     </MuiThemeProvider>
//   );
// }

// export default App;

// src/App.js
// App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import ShareLinks from './components/Display/ShareLinks';
import Layout from './components/Layout/LayOut';
import LandingPage from './components/LandingPage/LandingPage';
import { useTheme } from './context/ThemeContext';
import CssBaseline from '@mui/material/CssBaseline';
import ChatBot from './ChatBot/chatBot';
import FloatingButton from './components/FloatingButton/FloatingButton';
import Navbar from './components/NavBar/NavBar';
import { Box, Container, styled } from '@mui/material';
import './App.css';
import { UploadProvider } from './context/UploadContext';

// Create a wrapper component for conditional rendering
const ConditionalNavElements = () => {
  const location = useLocation();
  
  // Only show Navbar and FloatingButton on home page
  if (location.pathname === '/home') {
    return (
      <>
         <Navbar /> 
        <FloatingButton />
      </>
    );
  }
  
  return null;
};

function App() {
  const [fileLink, setFileLink] = useState('');
  const [fileName, setFileName] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const { isDarkMode } = useTheme();

  const handleFileUpload = async (file) => {
    const uploadedFileUrl = await window.firebaseService.uploadFile(file);
    setFileLink(uploadedFileUrl);
    setFileName(file.name);
  };

  return (
    
    <Router>
      {/* <ZebraBackground /> */}
      <MainWrapper>
        <ResponsiveContainer>
          <CssBaseline />
          
          {/* Use the conditional wrapper */}
          <ConditionalNavElements />

          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route 
              path="/home" 
              element={
                <>
                  <Layout 
                    fileLink={fileLink}
                    fileName={fileName}
                    isOpen={isOpen}
                    setIsOpen={setIsOpen}
                    onFileUpload={handleFileUpload}
                  />
                </>
              } 
            />
            <Route path="/Chatbot" element={<ChatBot />} />
          </Routes>
        </ResponsiveContainer>
      </MainWrapper>
    </Router>
   
  );
}

// Your existing styled components
const ZebraBackground = styled('div')({
  position: 'fixed',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  zIndex: -1,
  background: `
    repeating-linear-gradient(
      45deg,
      rgba(33, 150, 243, 0.05) 0px,
      rgba(33, 150, 243, 0.05) 100px,
      rgba(33, 203, 243, 0.05) 100px,
      rgba(33, 203, 243, 0.05) 200px
    )
  `,
  backgroundAttachment: 'fixed',
});

const MainWrapper = styled(Box)({
  minHeight: '100vh',
  position: 'relative',
  '&::before': {
    content: '""',
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'linear-gradient(180deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0.7) 100%)',
    zIndex: -1,
  },
});

const ResponsiveContainer = styled(Container)(({ theme }) => ({
  padding: '0 24px',
  [theme.breakpoints.up('sm')]: {
    padding: '0 40px',
  },
  [theme.breakpoints.up('md')]: {
    padding: '0 60px',
  },
  [theme.breakpoints.up('lg')]: {
    padding: '0 80px',
  },
  maxWidth: '1440px !important',
}));

export default App;
