// // const express = require('express');
// // const bodyParser = require('body-parser');
// // const axios = require('axios');
// // const fs = require('fs');
// // const path = require('path');

// // const app = express();
// // app.use(bodyParser.json());

// // // Change this line in your chatBot.js
// // const packageJsonPath = path.join(__dirname, '..',  '..', 'package.json');  // Going up three directories to reach the root
// //  // Changed this line to go up one directory

// // // Function to analyze dependencies
// // async function analyzeDependencies(packageJsonContent) {
// //     try {
// //         const dependencies = {
// //             ...packageJsonContent.dependencies,
// //             ...packageJsonContent.devDependencies
// //         };
// //         const results = [];

// //         for (const [pkg, version] of Object.entries(dependencies)) {
// //             const info = await getPackageInfo(pkg, version);
// //             results.push(info);
// //         }

// //         return formatResults(results);
// //     } catch (error) {
// //         return `Error analyzing dependencies: ${error.message}`;
// //     }
// // }


// // // Function to get package information
// // async function getPackageInfo(packageName, version) {
// //     try {
// //         const response = await axios.get(`https://registry.npmjs.org/${packageName}`);
// //         const data = response.data;
// //         const cleanVer = version.replace(/[\^~>=<]/g, '');

// //         const isDeprecated = data.deprecated || 
// //                            Object.values(data.versions).some(v => v.deprecated) ||
// //                            (data.versions[cleanVer] && data.versions[cleanVer].deprecated);

// //         return {
// //             package: packageName,
// //             currentVersion: version,
// //             latestVersion: data['dist-tags'].latest,
// //             deprecated: data.deprecated || 
// //                      (data.versions[cleanVer] && data.versions[cleanVer].deprecated) ||
// //                      false,
// //             deprecationMessage: data.versions[cleanVer]?.deprecated || null,
// //             isOutdated: cleanVer !== data['dist-tags'].latest
// //         };
// //     } catch (error) {
// //         return {
// //             package: packageName,
// //             error: `Error fetching package info: ${error.message}`
// //         };
// //     }
// // }

// // function formatResults(results) {
// //     let response = "📦 Dependency Analysis Report:\n\n";

// //     results.forEach(dep => {
// //         if (dep.error) {
// //             response += `❌ ${dep.package}: ${dep.error}\n\n`;
// //             return;
// //         }

// //         if (dep.deprecated) {
// //             response += `⛔ ${dep.package} is DEPRECATED!\n`;
// //             if (dep.deprecationMessage) {
// //                 response += `   Message: ${dep.deprecationMessage}\n`;
// //             }
// //             response += `   Current: ${dep.currentVersion}\n`;
// //             response += `   Latest: ${dep.latestVersion}\n\n`;
// //         } else if (dep.isOutdated) {
// //             response += `⚠️ ${dep.package} is outdated!\n`;
// //             response += `   Current: ${dep.currentVersion}\n`;
// //             response += `   Latest: ${dep.latestVersion}\n\n`;
// //         } else {
// //             response += `✅ ${dep.package} is up to date (${dep.currentVersion})\n\n`;
// //         }
// //     });

// //     return response;
// // }

// // // Chat endpoint
// // app.post('/chat', async (req, res) => {
// //     const message = req.body.message.toLowerCase();

// //     if (message.includes('dependabot') || message.includes('check dependencies')) {
// //         try {
// //             // Read package.json
// //              const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf-8'));
            
// //             // Analyze dependencies
// //             const analysis = await analyzeDependencies(packageJson);
            
// //             res.json({
// //                 response: analysis
// //             });
// //         } catch (error) {
// //             res.json({
// //                 response: `Error: ${error.message}`
// //             });
// //         }
// //     } else {
// //         res.json({
// //             response: "I can help you check package dependencies. Just mention 'dependabot' or 'check dependencies' in your message."
// //         });
// //     }
// // });

// // // Simple frontend
// // app.get('/', (req, res) => {
// //     res.sendFile(path.join(__dirname, 'chat.html'));
// // });

// // const PORT = process.env.PORT || 3000;
// // app.listen(PORT, () => {
// //     console.log(`Server running on port ${PORT}`);
// // });


// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// // Chatbot.js
// // import React, { useState, useEffect } from 'react';
// // import axios from 'axios';

// // const Chatbot = () => {
// //     const [messages, setMessages] = useState([]);
// //     const [inputMessage, setInputMessage] = useState('');
// //     const [loading, setLoading] = useState(false);
// //     const [packageJson, setPackageJson] = useState(null);

// //     // Load package.json when component mounts
// //     useEffect(() => {
// //         // Using relative path to fetch package.json
// //         fetch('/package.json')
// //             .then(response => response.json())
// //             .then(data => {
// //                 setPackageJson(data);
// //             })
// //             .catch(error => {
// //                 console.error('Error loading package.json:', error);
// //             });
// //     }, []);

// //     const mockNpmService = {
// //         getPackageInfo: async (packageName) => {
// //             try {
// //                 // Using npm registry API to get real package data
// //                 const response = await axios.get(`https://registry.npmjs.org/${packageName}`);
// //                 return {
// //                     'dist-tags': response.data['dist-tags'],
// //                     deprecated: response.data.deprecated || false
// //                 };
// //             } catch (error) {
// //                 console.error(`Error fetching ${packageName} info:`, error);
// //                 return {
// //                     'dist-tags': { latest: '0.0.0' },
// //                     deprecated: false
// //                 };
// //             }
// //         }
// //     };


// //     const analyzeDependencies = async () => {
// //         if (!packageJson) {
// //             return "Unable to load package.json file.";
// //         }

// //         const dependencies = {
// //             ...packageJson.dependencies,
// //             ...packageJson.devDependencies
// //         };
// //         const results = [];

// //         for (const [pkg, version] of Object.entries(dependencies)) {
// //             try {
// //                 const info = await mockNpmService.getPackageInfo(pkg);
// //                 const cleanVer = version.replace(/[\^~>=<]/g, '');
                
// //                 results.push({
// //                     package: pkg,
// //                     currentVersion: version,
// //                     latestVersion: info['dist-tags'].latest,
// //                     deprecated: info.deprecated || false,
// //                     isOutdated: cleanVer !== info['dist-tags'].latest,
// //                     type: packageJson.dependencies[pkg] ? 'dependency' : 'devDependency'
// //                 });
// //             } catch (error) {
// //                 results.push({
// //                     package: pkg,
// //                     error: `Error fetching package info: ${error.message}`
// //                 });
// //             }
// //         }

// //         return formatDetailedResults(results);
// //     };

// //     const formatDetailedResults = (results) => {
// //         let response = "📦 Complete Package Analysis Report:\n\n";
        
// //         // Separate dependencies and devDependencies
// //         const deps = results.filter(r => r.type === 'dependency');
// //         const devDeps = results.filter(r => r.type === 'devDependency');

// //         response += "🔧 Dependencies:\n";
// //         response += "================\n";
// //         deps.forEach(dep => {
// //             response += formatPackageInfo(dep);
// //         });

// //         response += "\n📚 DevDependencies:\n";
// //         response += "==================\n";
// //         devDeps.forEach(dep => {
// //             response += formatPackageInfo(dep);
// //         });

// //         // Add summary section
// //         const outdatedDeps = results.filter(r => r.isOutdated).length;
// //         const deprecatedDeps = results.filter(r => r.deprecated).length;
// //         const upToDateDeps = results.filter(r => !r.isOutdated && !r.deprecated).length;

// //         response += "\n📊 Summary:\n";
// //         response += "==========\n";
// //         response += `Total Packages: ${results.length}\n`;
// //         response += `Up to date: ${upToDateDeps}\n`;
// //         response += `Outdated: ${outdatedDeps}\n`;
// //         response += `Deprecated: ${deprecatedDeps}\n`;

// //         return response;
// //     };

// //     const formatPackageInfo = (dep) => {
// //         if (dep.error) {
// //             return `❌ ${dep.package}: ${dep.error}\n`;
// //         }

// //         let status = dep.isOutdated ? "⚠️ Outdated" : "✅ Up to date";
// //         if (dep.deprecated) status = "⛔ DEPRECATED";

// //         return `${dep.package}
// //     Current: ${dep.currentVersion}
// //     Latest:  ${dep.latestVersion}
// //     Status:  ${status}\n\n`;
// //     };

// //     const handleSendMessage = async () => {
// //         if (!inputMessage.trim()) return;

// //         const userMessage = {
// //             type: 'user',
// //             content: inputMessage
// //         };
// //         setMessages(prev => [...prev, userMessage]);
// //         setLoading(true);

// //         let response;
// //         if (inputMessage.toLowerCase().includes('dependabot') || 
// //             inputMessage.toLowerCase().includes('check dependencies') ||
// //             inputMessage.toLowerCase().includes('packages')) {
// //             response = await analyzeDependencies();
// //         } else {
// //             response = "I can help you check all your package dependencies. Try asking me to:\n" +
// //                       "- 'check dependencies'\n" +
// //                       "- 'show all packages'\n" +
// //                       "- 'analyze dependencies'";
// //         }

// //         const botMessage = {
// //             type: 'bot',
// //             content: response
// //         };
// //         setMessages(prev => [...prev, botMessage]);
// //         setLoading(false);
// //         setInputMessage('');
// //     };

// //     return (
// //         <div className="chatbot-container">
// //             <div className="chat-messages">
// //                 {messages.map((message, index) => (
// //                     <div key={index} className={`message ${message.type}`}>
// //                         <pre>{message.content}</pre>
// //                     </div>
// //                 ))}
// //                 {loading && <div className="message bot">Analyzing all packages...</div>}
// //             </div>
// //             <div className="chat-input">
// //                 <input
// //                     type="text"
// //                     value={inputMessage}
// //                     onChange={(e) => setInputMessage(e.target.value)}
// //                     onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
// //                     placeholder="Type 'check dependencies' to analyze packages..."
// //                 />
// //                 <button onClick={handleSendMessage}>Send</button>
// //             </div>
// //             <style jsx>{`
// //                 .chatbot-container {
// //                     max-width: 800px;
// //                     margin: 0 auto;
// //                     padding: 20px;
// //                     border: 1px solid #ddd;
// //                     border-radius: 8px;
// //                     height: 600px;
// //                     display: flex;
// //                     flex-direction: column;
// //                     background-color: #ffffff;
// //                 }

// //                 .chat-messages {
// //                     flex-grow: 1;
// //                     overflow-y: auto;
// //                     padding: 10px;
// //                     margin-bottom: 20px;
// //                 }

// //                 .message {
// //                     margin: 10px 0;
// //                     padding: 10px;
// //                     border-radius: 8px;
// //                     max-width: 90%;
// //                 }

// //                 .message.user {
// //                     background-color: #e3f2fd;
// //                     margin-left: auto;
// //                 }

// //                 .message.bot {
// //                     background-color: #f5f5f5;
// //                     margin-right: auto;
// //                     font-family: monospace;
// //                 }

// //                 .message pre {
// //                     white-space: pre-wrap;
// //                     word-wrap: break-word;
// //                     margin: 0;
// //                     font-family: monospace;
// //                 }

// //                 .chat-input {
// //                     display: flex;
// //                     gap: 10px;
// //                 }

// //                 input {
// //                     flex-grow: 1;
// //                     padding: 10px;
// //                     border: 1px solid #ddd;
// //                     border-radius: 4px;
// //                     font-size: 14px;
// //                 }

// //                 button {
// //                     padding: 10px 20px;
// //                     background-color: #007bff;
// //                     color: white;
// //                     border: none;
// //                     border-radius: 4px;
// //                     cursor: pointer;
// //                     font-weight: bold;
// //                 }

// //                 button:hover {
// //                     background-color: #0056b3;
// //                 }
// //             `}</style>
// //         </div>
// //     );
// // };

// // export default Chatbot;

// ///////////////////////////////////////////////////////////////////////////////////////////////////

// // src/components/Chatbot/Chatbot.js
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { Box, IconButton, Paper, Fade } from '@mui/material';
// import CloseIcon from '@mui/icons-material/Close';
// import { Modal } from '@mui/material';
// import { useNavigate } from 'react-router-dom';
// import { useUploadStore } from '../store/useUploadStore';


// const Chatbot = ({ onClose }) => {
//   const [messages, setMessages] = useState([]);
//   const [inputMessage, setInputMessage] = useState('');
//   const [loading, setLoading] = useState(false);
//   const [packageJson, setPackageJson] = useState(null);
//   const navigate = useNavigate();
//    const uploadedFile = useUploadStore((state) => state.uploadedFile);

//   useEffect(() => {
//   if (uploadedFile) {
//     console.log('File in chatbot page:', uploadedFile.name);
//   }
// }, [uploadedFile]);


//   // useEffect(() => {
//   //   fetch('/package.json')
//   //     .then((res) => res.json())
//   //     .then((data) => setPackageJson(data))
//   //     .catch((err) => console.error('Error loading package.json:', err));
//   // }, []);

//   const mockNpmService = {
//     getPackageInfo: async (packageName) => {
//       try {
//         const res = await axios.get(`https://registry.npmjs.org/${packageName}`);
//         return {
//           'dist-tags': res.data['dist-tags'],
//           deprecated: res.data.deprecated || false
//         };
//       } catch (err) {
//         return {
//           'dist-tags': { latest: '0.0.0' },
//           deprecated: false
//         };
//       }
//     }
//   };

//   const analyzeDependencies = async () => {
//     if (!packageJson) return 'Unable to load package.json file.';
//     const dependencies = {
//       ...packageJson.dependencies,
//       ...packageJson.devDependencies
//     };

//     const results = [];
//     for (const [pkg, version] of Object.entries(dependencies)) {
//       const info = await mockNpmService.getPackageInfo(pkg);
//       const cleanVer = version.replace(/[\^~>=<]/g, '');
//       results.push({
//         package: pkg,
//         currentVersion: version,
//         latestVersion: info['dist-tags'].latest,
//         deprecated: info.deprecated,
//         isOutdated: cleanVer !== info['dist-tags'].latest,
//         type: packageJson.dependencies[pkg] ? 'dependency' : 'devDependency'
//       });
//     }

//     return formatDetailedResults(results);
//   };

//   const formatDetailedResults = (results) => {
//     let response = '📦 Package Analysis Report:\n\n';
//     const deps = results.filter((r) => r.type === 'dependency');
//     const devDeps = results.filter((r) => r.type === 'devDependency');

//     response += '🔧 Dependencies:\n';
//     response += '================\n';
//     deps.forEach((dep) => (response += formatPackageInfo(dep)));

//     response += '\n📚 DevDependencies:\n';
//     response += '==================\n';
//     devDeps.forEach((dep) => (response += formatPackageInfo(dep)));

//     const summary = {
//       outdated: results.filter((r) => r.isOutdated).length,
//       deprecated: results.filter((r) => r.deprecated).length,
//       upToDate: results.filter((r) => !r.isOutdated && !r.deprecated).length
//     };

//     response += '\n📊 Summary:\n';
//     response += '==========\n';
//     response += `Total: ${results.length}\nUp to date: ${summary.upToDate}\nOutdated: ${summary.outdated}\nDeprecated: ${summary.deprecated}\n`;

//     return response;
//   };

//   const formatPackageInfo = (dep) => {
//     let status = dep.isOutdated ? '⚠️ Outdated' : '✅ Up to date';
//     if (dep.deprecated) status = '⛔ DEPRECATED';

//     return `${dep.package}
//     Current: ${dep.currentVersion}
//     Latest:  ${dep.latestVersion}
//     Status:  ${status}\n\n`;
//   };

//   const handleSendMessage = async () => {
//     if (!inputMessage.trim()) return;

//     const userMessage = { type: 'user', content: inputMessage };
//     setMessages((prev) => [...prev, userMessage]);
//     setLoading(true);

//     let response;
//     if (
//       inputMessage.toLowerCase().includes('dependabot') ||
//       inputMessage.toLowerCase().includes('check dependencies') ||
//       inputMessage.toLowerCase().includes('packages')
//     ) {
//       response = await analyzeDependencies();
//     } else {
//       response =
//         "I can help you check your project packages. Try:\n- 'check dependencies'\n- 'analyze packages'\n- 'are any deprecated?'\n";
//     }

//     setMessages((prev) => [...prev, { type: 'bot', content: response }]);
//     setLoading(false);
//     setInputMessage('');
//   };

//   return (
//    <Modal
//   open={true}
//   onClose={onClose}
//   sx={{
//     display: 'flex',
//     justifyContent: 'center',
//     alignItems: 'center',
//     backdropFilter: 'blur(8px)',
//     backgroundColor: 'rgba(0, 0, 0, 0.2)', // subtle transparent dark overlay
//   }}
// >
//       {/* <Box
//         sx={{
//           position: 'fixed',
//           top: 0,
//           left: 0,
//           width: '100vw',
//           height: '100vh',
//           backgroundColor: 'rgba(220, 13, 13, 0.2)', // ✅ updated
//     backdropFilter: 'blur(6px)',
//           display: 'flex',
//           justifyContent: 'center',
//           alignItems: 'center',
//           zIndex: 1400,
//         }}
//       > */}
//         <Paper
//           elevation={6}
//           sx={{
//             position: 'relative',
//             width: '90%',
//             maxWidth: '600px',
//             height: '80vh',
//             p: 3,
//             borderRadius: 3,
//             backgroundColor: '#fff',
//             display: 'flex',
//             flexDirection: 'column',
//             overflow: 'hidden',
//           }}
//         >
//           <IconButton
//   onClick={() => navigate('/home')}
//   sx={{ position: 'absolute', top: 8, right: 8 }}
//   aria-label="Close chatbot"
// >
//   <CloseIcon />
// </IconButton>


//           <Box
//             sx={{
//               flex: 1,
//               overflowY: 'auto',
//               mb: 2,
//             }}
//           >
//             {messages.map((msg, idx) => (
//               <Box
//                 key={idx}
//                 sx={{
//                   my: 1,
//                   px: 2,
//                   py: 1,
//                   backgroundColor: msg.type === 'user' ? '#e3f2fd' : '#f1f1f1',
//                   alignSelf: msg.type === 'user' ? 'flex-end' : 'flex-start',
//                   borderRadius: 2,
//                   whiteSpace: 'pre-wrap',
//                   fontFamily: 'monospace',
//                 }}
//               >
//                 {msg.content}
//               </Box>
//             ))}
//             {loading && <Box sx={{ fontStyle: 'italic' }}>Analyzing all packages...</Box>}
//           </Box>

//           <Box sx={{ display: 'flex', gap: 1 }}>
//             <input
//               value={inputMessage}
//               onChange={(e) => setInputMessage(e.target.value)}
//               onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
//               placeholder="Type 'check dependencies'..."
//               style={{
//                 flex: 1,
//                 padding: '10px',
//                 borderRadius: '4px',
//                 border: '1px solid #ccc',
//               }}
//             />
//             <button
//               onClick={handleSendMessage}
//               style={{
//                 padding: '10px 16px',
//                 background: '#1976d2',
//                 color: 'white',
//                 border: 'none',
//                 borderRadius: '4px',
//                 fontWeight: 'bold',
//                 cursor: 'pointer',
//               }}
//             >
//               Send
//             </button>
//           </Box>
//         </Paper>
//       {/* </Box> */}
//     </Modal>
//   );
// };

// export default Chatbot;
// src/components/Chatbot/Chatbot.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Box, Button, IconButton, Paper, Modal } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useNavigate } from 'react-router-dom';

import { useUploadStore } from '../store/useUploadStore';

const Chatbot = ({ onClose }) => {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [packageJson, setPackageJson] = useState(null);
  const [apiAnalysis, setApiAnalysis] = useState('');
  const [apiAnalysis1, setApiAnalysis1] = useState('');
  const navigate = useNavigate();
  const uploadedFile = useUploadStore((state) => state.uploadedFile);
  

  useEffect(() => {
    if (uploadedFile) {
      console.log('File in chatbot page:', uploadedFile.name);
    }
  }, [uploadedFile]);

  // useEffect(() => {
  //   fetch('/package.json')
  //     .then((res) => res.json())
  //     .then((data) => setPackageJson(data))
  //     .catch((err) => console.error('Error loading package.json:', err));
  // }, []);

  const mockNpmService = {
    getPackageInfo: async (pkg) => {
      try {
        const res = await axios.get(`https://registry.npmjs.org/${pkg}`);
        return {
          'dist-tags': res.data['dist-tags'],
          deprecated: res.data.deprecated || false
        };
      } catch {
        return { 'dist-tags': { latest: '0.0.0' }, deprecated: false };
      }
    }
  };

 const analyzeDependencies = async () => {
  if (!uploadedFile) {
    alert('No file uploaded!');
    return;
  }

  const formData = new FormData();
  formData.append('file', uploadedFile);

  try {
    setLoading(true);
    const response = await axios.post(
      'http://localhost:8000/analyze-code',
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );

    console.log('Code Analysis API Response:', response.data);

    // ✅ Extract content from nested structure
    const content = response?.data?.report?.choices?.[0]?.message?.content;

    if (content) {
      setApiAnalysis1(content); // Show report in UI
    } else {
      setApiAnalysis1('No code analysis found in response.');
    }

  } catch (error) {
    console.error('Error during code analysis:', error);
    setApiAnalysis1('❌ Code analysis failed.');
  } finally {
    setLoading(false);
  }
};


  const formatPackageInfo = (dep) => {
  let status = '✅ Up to date';
  if (dep.deprecated) status = '⛔ DEPRECATED';
  else if (dep.isOutdated) status = '⚠️ Outdated';

  return `${dep.package}
Current: ${dep.currentVersion}
Latest:  ${dep.latestVersion}
Status:  ${status}\n`;
};



  //   const handleDependencyAnalysis = async () => {
  //   if (!uploadedFile) {
  //     console.warn('No uploaded file to analyze');
  //     return;
  //   }

  //   setLoading(true);
  //   try {
  //     const response = await axios.post('http://0.0.0.0:8001/analyze/', {
  //       uploadedFile: uploadedFile.name || uploadedFile,  // Adjust based on what your backend expects
  //     });

  //     console.log('Dependency Analysis Result:', response.data);
  //     // Handle response UI here (e.g., toast, dialog, next steps)

  //   } catch (error) {
  //     console.error('Error during dependency analysis:', error);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  const handleDependencyAnalysis = async () => {
  if (!uploadedFile) {
    alert('No file uploaded!');
    return;
  }

  const formData = new FormData();
 formData.append('file', uploadedFile);
 // make sure backend expects 'uploadedfile' as key

  try {
    const response = await axios.post(
      'http://localhost:8001/analyze/',
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );
    console.log('API response:', response.data);
    // Extract analysis from results array
    if (response.data.results && response.data.results.length > 0) {
      setApiAnalysis(response.data.results[0].analysis);
    } else {
      setApiAnalysis('No analysis found in response.');
    }
    
    // handle success (e.g., show results)
  } catch (error) {
    console.error('API call error:', error);
    // handle error (e.g., show message)
  }
};

  
  const formatResults = (results) => {
  let resp = '📦 Package Analysis Report:\n\n';

  const outlines = results.filter(r => r.isOutdated).length;
  const deprs = results.filter(r => r.deprecated).length;

  results.forEach(dep => {
    resp += formatPackageInfo(dep) + '\n';
  });

  resp += `📊 Summary:
Total Packages: ${results.length}
Up‑to‑date: ${results.length - outlines - deprs}
Outdated: ${outlines}
Deprecated: ${deprs}`;

  return resp;
};

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;
    setMessages(m => [...m, { type: 'user', content: inputMessage }]);
    if (/dependabot|check dependencies|packages/i.test(inputMessage)) {
      await analyzeDependencies();
    } else {
      setMessages(m => [...m, { type: 'bot', content: "Try typing 'check dependencies' to analyze your packages." }]);
    }
    setInputMessage('');
  };

  return (
    <Modal open onClose={onClose} sx={{ display:'flex', justifyContent:'center', alignItems:'center', backdropFilter:'blur(8px)', backgroundColor:'rgba(0,0,0,0.2)' }}>
      <Paper elevation={6} sx={{ position:'relative', width:'90%', maxWidth:'600px', height:'80vh', p:3, borderRadius:3, display:'flex', flexDirection:'column' }}>
        <IconButton  onClick={() => navigate('/home')} sx={{ position:'absolute', top:8, right:8 }}>
          <CloseIcon />
        </IconButton>

        <Box sx={{ flex:1, overflowY:'auto', mb:2 }}>
          {messages.map((msg,i) => (
            <Box key={i} sx={{ my:1, px:2, py:1, backgroundColor: msg.type === 'user' ? '#e3f2fd' : '#f1f1f1', alignSelf: msg.type === 'user' ? 'flex-end' : 'flex-start', borderRadius:2, whiteSpace:'pre-wrap', fontFamily:'monospace' }}>
              {msg.content}
            </Box>
          ))}
          {loading && <Box sx={{ fontStyle:'italic' }}>Analyzing all packages...</Box>}
        </Box>
       {apiAnalysis1 && (
  <Box
    sx={{
      mt: 3,
      p: 3,
      bgcolor: '#ffffff',
      borderRadius: 3,
      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
      whiteSpace: 'pre-wrap',
      maxHeight: 450,
      overflowY: 'auto',
fontFamily: `'Segoe UI Emoji', 'Segoe UI Symbol', 'Apple Color Emoji', 'Noto Color Emoji', sans-serif`,
      fontSize: '0.95rem',
      color: '#333',
      border: '1px solid #e0e0e0',
      lineHeight: 1.5,
      '&::-webkit-scrollbar': {
        width: 8,
        backgroundColor: '#f5f5f5',
        borderRadius: 4,
      },
      '&::-webkit-scrollbar-thumb': {
        backgroundColor: '#c1c1c1',
        borderRadius: 4,
      },
      scrollbarWidth: 'thin',
      scrollbarColor: '#c1c1c1 #f5f5f5',
    }}
    role="region"
    aria-label="API analysis report"
  >
    {apiAnalysis1}
  </Box>
)}
       {apiAnalysis && (
  <Box
    sx={{
      mt: 3,
      p: 3,
      bgcolor: '#ffffff',
      borderRadius: 3,
      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
      whiteSpace: 'pre-wrap',
      maxHeight: 450,
      overflowY: 'auto',
fontFamily: `'Segoe UI Emoji', 'Segoe UI Symbol', 'Apple Color Emoji', 'Noto Color Emoji', sans-serif`,
      fontSize: '0.95rem',
      color: '#333',
      border: '1px solid #e0e0e0',
      lineHeight: 1.5,
      '&::-webkit-scrollbar': {
        width: 8,
        backgroundColor: '#f5f5f5',
        borderRadius: 4,
      },
      '&::-webkit-scrollbar-thumb': {
        backgroundColor: '#c1c1c1',
        borderRadius: 4,
      },
      scrollbarWidth: 'thin',
      scrollbarColor: '#c1c1c1 #f5f5f5',
    }}
    role="region"
    aria-label="API analysis report"
  >
    {apiAnalysis}
  </Box>
)}

        {/* Two Buttons */}
        <Box sx={{ display:'flex', justifyContent:'space-between', gap:1, mb:2 }}>
          <Button variant="contained" color="primary" onClick={analyzeDependencies} disabled={loading}>
            Code Analysis
          </Button>

           <Button
        variant="contained"
        color="primary"
        onClick={handleDependencyAnalysis}
        disabled={loading}
      >
        Dependency Analyzer
      </Button>
        </Box>

        <Box sx={{ display:'flex', gap:1 }}>
          <input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={(e) => e.key==='Enter' && handleSendMessage()}
            placeholder="Type 'check dependencies'..."
            style={{ flex:1, padding:10, borderRadius:4, border:'1px solid #ccc' }}
          />
          <button
            onClick={handleSendMessage}
            style={{ padding:'10px 16px', background:'#1976d2', color:'#fff', border:'none', borderRadius:4, fontWeight:'bold', cursor:'pointer' }}
          >
            Send
          </button>
        </Box>
      </Paper>
    </Modal>
  );
};

export default Chatbot;
