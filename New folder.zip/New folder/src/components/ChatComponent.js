// // ChatComponent.jsx
// import React, { useState, useRef, useEffect } from 'react';
// import { Box, TextField, Button, Typography, Paper, CircularProgress, Chip } from '@mui/material';
// import OpenAI from 'openai';
// // Import package.json directly
// import packageJson from '../../package.json';

// const ChatComponent = () => {
//   const [messages, setMessages] = useState([]);
//   const [input, setInput] = useState('');
//   const [isLoading, setIsLoading] = useState(false);
//   const messagesEndRef = useRef(null);

//   // Initialize OpenAI client
//   const openai = new OpenAI({
//     apiKey: 'your-api-key', // Replace with your API key
//     dangerouslyAllowBrowser: true
//   });

//   const scrollToBottom = () => {
//     messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
//   };

//   useEffect(() => {
//     scrollToBottom();
//   }, [messages]);

//   const analyzeDependencies = async () => {
//     try {
//       const dependencies = {
//         ...packageJson.dependencies,
//         ...packageJson.devDependencies
//       };

//       // Fetch latest versions from npm registry
//       const dependencyAnalysis = await Promise.all(
//         Object.entries(dependencies).map(async ([name, version]) => {
//           try {
//             const response = await fetch(`https://registry.npmjs.org/${name}`);
//             const data = await response.json();
//             const currentVersion = version.replace('^', '').replace('~', '');
//             const latestVersion = data['dist-tags'].latest;
//             const versions = Object.keys(data.versions);
            
//             // Get major security updates
//             const securityUpdates = versions.filter(v => {
//               const [major] = v.split('.');
//               const [currentMajor] = currentVersion.split('.');
//               return parseInt(major) > parseInt(currentMajor);
//             });

//             // Get minor and patch updates
//             const minorUpdates = versions.filter(v => {
//               const [major, minor] = v.split('.');
//               const [currentMajor, currentMinor] = currentVersion.split('.');
//               return major === currentMajor && parseInt(minor) > parseInt(currentMinor);
//             });

//             return {
//               name,
//               currentVersion,
//               latestVersion,
//               hasUpdate: currentVersion !== latestVersion,
//               securityUpdates: securityUpdates.length > 0,
//               minorUpdates: minorUpdates.length > 0,
//               recommendedVersion: latestVersion,
//               updateType: securityUpdates.length > 0 ? 'SECURITY' : 
//                          minorUpdates.length > 0 ? 'MINOR' : 'NONE'
//             };
//           } catch (error) {
//             console.error(`Error analyzing ${name}:`, error);
//             return {
//               name,
//               currentVersion: version,
//               error: true
//             };
//           }
//         })
//       );

//       return dependencyAnalysis;
//     } catch (error) {
//       console.error('Error analyzing dependencies:', error);
//       throw error;
//     }
//   };

//   const handleSend = async () => {
//     if (!input.trim()) return;

//     const userMessage = {
//       type: 'user',
//       content: input,
//       timestamp: new Date()
//     };

//     setMessages(prev => [...prev, userMessage]);
//     setInput('');
//     setIsLoading(true);

//     try {
//       if (input.toLowerCase().includes('dependabot')) {
//         const analysis = await analyzeDependencies();
        
//         // Generate AI response based on analysis
//         const prompt = `
//           Act as a dependency analysis bot like Dependabot. Analyze these package updates:
//           ${JSON.stringify(analysis, null, 2)}
          
//           Provide a detailed report with:
//           1. Critical security updates needed
//           2. Recommended version upgrades
//           3. Breaking changes warnings
//           4. Update priority levels
          
//           Format the response in a clear, actionable way.
//         `;

//         const completion = await openai.chat.completions.create({
//           messages: [{ role: "user", content: prompt }],
//           model: "gpt-3.5-turbo",
//         });

//         setMessages(prev => [...prev, {
//           type: 'ai',
//           content: completion.choices[0].message.content,
//           analysis: analysis,
//           timestamp: new Date()
//         }]);
//       } else {
//         // Handle other chat interactions...
//         const completion = await openai.chat.completions.create({
//           messages: [{ role: "user", content: input }],
//           model: "gpt-3.5-turbo",
//         });

//         setMessages(prev => [...prev, {
//           type: 'ai',
//           content: completion.choices[0].message.content,
//           timestamp: new Date()
//         }]);
//       }
//     } catch (error) {
//       console.error('Error:', error);
//       setMessages(prev => [...prev, {
//         type: 'ai',
//         content: 'Error analyzing dependencies. Please check the console for details.',
//         isError: true,
//         timestamp: new Date()
//       }]);
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const renderDependencyAnalysis = (analysis) => {
//     return (
//       <Box sx={{ mt: 2 }}>
//         {analysis.map((dep) => (
//           <Paper
//             key={dep.name}
//             sx={{
//               p: 1,
//               mt: 1,
//               bgcolor: dep.securityUpdates ? '#ff5252' : 
//                        dep.minorUpdates ? '#fb8c00' : '#424242',
//               display: 'flex',
//               justifyContent: 'space-between',
//               alignItems: 'center'
//             }}
//           >
//             <Box>
//               <Typography variant="subtitle2" color="white">
//                 {dep.name}
//               </Typography>
//               <Typography variant="caption" color="rgba(255,255,255,0.7)">
//                 Current: {dep.currentVersion} → Latest: {dep.latestVersion}
//               </Typography>
//             </Box>
//             <Box>
//               {dep.updateType === 'SECURITY' && (
//                 <Chip
//                   label="Security Update"
//                   color="error"
//                   size="small"
//                   sx={{ mr: 1 }}
//                 />
//               )}
//               {dep.updateType === 'MINOR' && (
//                 <Chip
//                   label="Minor Update"
//                   color="warning"
//                   size="small"
//                   sx={{ mr: 1 }}
//                 />
//               )}
//             </Box>
//           </Paper>
//         ))}
//       </Box>
//     );
//   };

//   return (
//     <Box sx={{ maxWidth: 800, margin: 'auto', p: 2 }}>
//       <Paper 
//         elevation={3} 
//         sx={{ 
//           height: '70vh', 
//           p: 2, 
//           display: 'flex', 
//           flexDirection: 'column',
//           bgcolor: '#1a1a1a'
//         }}
//       >
//         <Box sx={{ flexGrow: 1, overflow: 'auto', mb: 2 }}>
//           {messages.map((message, index) => (
//             <Box
//               key={index}
//               sx={{
//                 display: 'flex',
//                 justifyContent: message.type === 'user' ? 'flex-end' : 'flex-start',
//                 mb: 2
//               }}
//             >
//               <Paper
//                 sx={{
//                   p: 2,
//                   maxWidth: '80%',
//                   bgcolor: message.type === 'user' ? '#2962ff' : '#333333',
//                   color: 'white'
//                 }}
//               >
//                 <Typography>{message.content}</Typography>
//                 {message.analysis && renderDependencyAnalysis(message.analysis)}
//               </Paper>
//             </Box>
//           ))}
//           <div ref={messagesEndRef} />
//         </Box>
//         <Box sx={{ display: 'flex', gap: 1 }}>
//           <TextField
//             fullWidth
//             value={input}
//             onChange={(e) => setInput(e.target.value)}
//             placeholder="Type 'dependabot' to scan dependencies"
//             onKeyPress={(e) => e.key === 'Enter' && handleSend()}
//             disabled={isLoading}
//             sx={{
//               '& .MuiOutlinedInput-root': {
//                 color: 'white',
//                 '& fieldset': {
//                   borderColor: 'rgba(255,255,255,0.3)',
//                 },
//                 '&:hover fieldset': {
//                   borderColor: 'rgba(255,255,255,0.5)',
//                 },
//               }
//             }}
//           />
//           <Button 
//             variant="contained" 
//             onClick={handleSend}
//             disabled={isLoading}
//             sx={{ minWidth: 100 }}
//           >
//             {isLoading ? <CircularProgress size={24} /> : 'Send'}
//           </Button>
//         </Box>
//       </Paper>
//     </Box>
//   );
// };

// export default ChatComponent;
