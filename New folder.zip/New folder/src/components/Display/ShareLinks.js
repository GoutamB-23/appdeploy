import React from 'react';
import { Box, Typography } from '@mui/material';
import QRCode from 'react-qr-code';
import { useSpring, animated } from '@react-spring/web';

function ShareLinks({ link, filename }) {
      const fadeProps = useSpring({
    from: { opacity: 0 },
    to: { opacity: 1 },
    delay: 300, // Delay for a smoother entrance
  });

  return (
    <animated.div style={fadeProps}>
    <Box>
      <Typography variant="h6">Download Link:</Typography>
      <Typography variant="body1" gutterBottom>
        {link}
      </Typography>
      <Typography variant="h6" gutterBottom>QR Code:</Typography>
      <Box sx={{ display: 'flex', justifyContent: 'center' }}>
        <QRCode value={link} size={200} />
      </Box>
    </Box>
    </animated.div>
  );
}

export default ShareLinks;





// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { Box, IconButton, Paper, Fade } from '@mui/material';
// import CloseIcon from '@mui/icons-material/Close';
// import { Modal } from '@mui/material';
// import { useNavigate } from 'react-router-dom';
// import { useUploadStore } from '../store/useUploadStore';


// const Chatbot = ({ onClose }) => {
//   const [messages, setMessages] = useState([]);
//   const [inputMessage, setInputMessage] = useState('');
//   const [loading, setLoading] = useState(false);
//   const [packageJson, setPackageJson] = useState(null);
//   const navigate = useNavigate();
//    const uploadedFile = useUploadStore((state) => state.uploadedFile);

//   useEffect(() => {
//   if (uploadedFile) {
//     console.log('File in chatbot page:', uploadedFile.name);
//   }
// }, [uploadedFile]);


//   // useEffect(() => {
//   //   fetch('/package.json')
//   //     .then((res) => res.json())
//   //     .then((data) => setPackageJson(data))
//   //     .catch((err) => console.error('Error loading package.json:', err));
//   // }, []);

//   const mockNpmService = {
//     getPackageInfo: async (packageName) => {
//       try {
//         const res = await axios.get(`https://registry.npmjs.org/${packageName}`);
//         return {
//           'dist-tags': res.data['dist-tags'],
//           deprecated: res.data.deprecated || false
//         };
//       } catch (err) {
//         return {
//           'dist-tags': { latest: '0.0.0' },
//           deprecated: false
//         };
//       }
//     }
//   };

//   const analyzeDependencies = async () => {
//     if (!packageJson) return 'Unable to load package.json file.';
//     const dependencies = {
//       ...packageJson.dependencies,
//       ...packageJson.devDependencies
//     };

//     const results = [];
//     for (const [pkg, version] of Object.entries(dependencies)) {
//       const info = await mockNpmService.getPackageInfo(pkg);
//       const cleanVer = version.replace(/[\^~>=<]/g, '');
//       results.push({
//         package: pkg,
//         currentVersion: version,
//         latestVersion: info['dist-tags'].latest,
//         deprecated: info.deprecated,
//         isOutdated: cleanVer !== info['dist-tags'].latest,
//         type: packageJson.dependencies[pkg] ? 'dependency' : 'devDependency'
//       });
//     }

//     return formatDetailedResults(results);
//   };

//   const formatDetailedResults = (results) => {
//     let response = '📦 Package Analysis Report:\n\n';
//     const deps = results.filter((r) => r.type === 'dependency');
//     const devDeps = results.filter((r) => r.type === 'devDependency');

//     response += '🔧 Dependencies:\n';
//     response += '================\n';
//     deps.forEach((dep) => (response += formatPackageInfo(dep)));

//     response += '\n📚 DevDependencies:\n';
//     response += '==================\n';
//     devDeps.forEach((dep) => (response += formatPackageInfo(dep)));

//     const summary = {
//       outdated: results.filter((r) => r.isOutdated).length,
//       deprecated: results.filter((r) => r.deprecated).length,
//       upToDate: results.filter((r) => !r.isOutdated && !r.deprecated).length
//     };

//     response += '\n📊 Summary:\n';
//     response += '==========\n';
//     response += `Total: ${results.length}\nUp to date: ${summary.upToDate}\nOutdated: ${summary.outdated}\nDeprecated: ${summary.deprecated}\n`;

//     return response;
//   };

//   const formatPackageInfo = (dep) => {
//     let status = dep.isOutdated ? '⚠️ Outdated' : '✅ Up to date';
//     if (dep.deprecated) status = '⛔ DEPRECATED';

//     return `${dep.package}
//     Current: ${dep.currentVersion}
//     Latest:  ${dep.latestVersion}
//     Status:  ${status}\n\n`;
//   };

//   const handleSendMessage = async () => {
//     if (!inputMessage.trim()) return;

//     const userMessage = { type: 'user', content: inputMessage };
//     setMessages((prev) => [...prev, userMessage]);
//     setLoading(true);

//     let response;
//     if (
//       inputMessage.toLowerCase().includes('dependabot') ||
//       inputMessage.toLowerCase().includes('check dependencies') ||
//       inputMessage.toLowerCase().includes('packages')
//     ) {
//       response = await analyzeDependencies();
//     } else {
//       response =
//         "I can help you check your project packages. Try:\n- 'check dependencies'\n- 'analyze packages'\n- 'are any deprecated?'\n";
//     }

//     setMessages((prev) => [...prev, { type: 'bot', content: response }]);
//     setLoading(false);
//     setInputMessage('');
//   };

//   return (
//    <Modal
//   open={true}
//   onClose={onClose}
//   sx={{
//     display: 'flex',
//     justifyContent: 'center',
//     alignItems: 'center',
//     backdropFilter: 'blur(8px)',
//     backgroundColor: 'rgba(0, 0, 0, 0.2)', // subtle transparent dark overlay
//   }}
// >
//       {/* <Box
//         sx={{
//           position: 'fixed',
//           top: 0,
//           left: 0,
//           width: '100vw',
//           height: '100vh',
//           backgroundColor: 'rgba(220, 13, 13, 0.2)', // ✅ updated
//     backdropFilter: 'blur(6px)',
//           display: 'flex',
//           justifyContent: 'center',
//           alignItems: 'center',
//           zIndex: 1400,
//         }}
//       > */}
//         <Paper
//           elevation={6}
//           sx={{
//             position: 'relative',
//             width: '90%',
//             maxWidth: '600px',
//             height: '80vh',
//             p: 3,
//             borderRadius: 3,
//             backgroundColor: '#fff',
//             display: 'flex',
//             flexDirection: 'column',
//             overflow: 'hidden',
//           }}
//         >
//           <IconButton
//   onClick={() => navigate('/home')}
//   sx={{ position: 'absolute', top: 8, right: 8 }}
//   aria-label="Close chatbot"
// >
//   <CloseIcon />
// </IconButton>


//           <Box
//             sx={{
//               flex: 1,
//               overflowY: 'auto',
//               mb: 2,
//             }}
//           >
//             {messages.map((msg, idx) => (
//               <Box
//                 key={idx}
//                 sx={{
//                   my: 1,
//                   px: 2,
//                   py: 1,
//                   backgroundColor: msg.type === 'user' ? '#e3f2fd' : '#f1f1f1',
//                   alignSelf: msg.type === 'user' ? 'flex-end' : 'flex-start',
//                   borderRadius: 2,
//                   whiteSpace: 'pre-wrap',
//                   fontFamily: 'monospace',
//                 }}
//               >
//                 {msg.content}
//               </Box>
//             ))}
//             {loading && <Box sx={{ fontStyle: 'italic' }}>Analyzing all packages...</Box>}
//           </Box>

//           <Box sx={{ display: 'flex', gap: 1 }}>
//             <input
//               value={inputMessage}
//               onChange={(e) => setInputMessage(e.target.value)}
//               onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
//               placeholder="Type 'check dependencies'..."
//               style={{
//                 flex: 1,
//                 padding: '10px',
//                 borderRadius: '4px',
//                 border: '1px solid #ccc',
//               }}
//             />
//             <button
//               onClick={handleSendMessage}
//               style={{
//                 padding: '10px 16px',
//                 background: '#1976d2',
//                 color: 'white',
//                 border: 'none',
//                 borderRadius: '4px',
//                 fontWeight: 'bold',
//                 cursor: 'pointer',
//               }}
//             >
//               Send
//             </button>
//           </Box>
//         </Paper>
//       {/* </Box> */}
//     </Modal>
//   );
// };

// export default Chatbot;