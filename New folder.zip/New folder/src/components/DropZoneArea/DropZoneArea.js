// // src/components/DropZoneArea.js
// import React, { useCallback, useState } from 'react';
// import { useDropzone } from 'react-dropzone';
// import { 
//   Paper, 
//   Typography, 
//   Box, 
//   LinearProgress,
//   Checkbox,
//   FormControlLabel,
//   TextField,
//   Collapse,
//   InputAdornment,
//   IconButton
// } from '@mui/material';
// import CloudUploadIcon from '@mui/icons-material/CloudUpload';
// import VisibilityIcon from '@mui/icons-material/Visibility';
// import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
// import GitHubIcon from '@mui/icons-material/GitHub';
// import { motion } from 'framer-motion';

// function DropZoneArea() {
//   const [uploadProgress, setUploadProgress] = useState(0);
//   const [isUploading, setIsUploading] = useState(false);
//   const [showPassword, setShowPassword] = useState(false);
  
//   const [options, setOptions] = useState({
//     requirePassword: false,
//     showInWall: false,
//     updateGit: false,
//   });

//   const [passwords, setPasswords] = useState({
//     password: '',
//     confirmPassword: '',
//   });

//   const [gitCredentials, setGitCredentials] = useState({
//     username: '',
//     token: '',
//   });

//   const onDrop = useCallback((acceptedFiles) => {
//     setIsUploading(true);
//     // Simulate upload progress
//     let progress = 0;
//     const interval = setInterval(() => {
//       progress += 5;
//       setUploadProgress(progress);
//       if (progress >= 100) {
//         clearInterval(interval);
//         setIsUploading(false);
//         // Handle your file upload logic here
//         console.log('Uploaded files:', acceptedFiles);
//       }
//     }, 100);
//   }, []);

//   const { getRootProps, getInputProps, isDragActive } = useDropzone({
//     onDrop,
//     accept: {
//       'image/*': ['.jpeg', '.jpg', '.png'],
//       'application/pdf': ['.pdf'],
//       'application/msword': ['.doc', '.docx'],
//       'application/vnd.ms-excel': ['.xls', '.xlsx']
//     }
//   });

//   const handleOptionChange = (event) => {
//     setOptions({
//       ...options,
//       [event.target.name]: event.target.checked,
//     });
//   };

//   const handlePasswordChange = (event) => {
//     setPasswords({
//       ...passwords,
//       [event.target.name]: event.target.value,
//     });
//   };

//   const handleGitCredentialsChange = (event) => {
//     setGitCredentials({
//       ...gitCredentials,
//       [event.target.name]: event.target.value,
//     });
//   };

//   return (
//     <Box sx={{ width: '100%', maxWidth: 600, mx: 'auto', p: 2 }}>
//       <Paper
//         {...getRootProps()}
//         elevation={3}
//         sx={{
//           p: 3,
//           mb: 3,
//           backgroundColor: isDragActive ? 'rgba(25, 118, 210, 0.08)' : 'white',
//           border: isDragActive ? '2px dashed #1976d2' : '2px dashed #ccc',
//           borderRadius: 2,
//           cursor: 'pointer',
//           transition: 'all 0.3s ease',
//           '&:hover': {
//             borderColor: '#1976d2',
//             backgroundColor: 'rgba(25, 118, 210, 0.04)'
//           }
//         }}
//       >
//         <input {...getInputProps()} />
//         <Box
//           sx={{
//             display: 'flex',
//             flexDirection: 'column',
//             alignItems: 'center',
//             gap: 2
//           }}
//         >
//           <CloudUploadIcon sx={{ fontSize: 60, color: isDragActive ? '#1976d2' : '#757575' }} />
//           <Typography variant="h6" color={isDragActive ? 'primary' : 'textSecondary'}>
//             {isDragActive
//               ? 'Drop files here...'
//               : 'Drag & drop files here, or click to select files'}
//           </Typography>
//           <Typography variant="body2" color="textSecondary">
//             Supported files: Images, PDF, DOC, DOCX, XLS, XLSX
//           </Typography>
//           {isUploading && (
//             <Box sx={{ width: '100%', mt: 2 }}>
//               <LinearProgress variant="determinate" value={uploadProgress} />
//               <Typography variant="body2" color="textSecondary" align="center" sx={{ mt: 1 }}>
//                 Uploading... {uploadProgress}%
//               </Typography>
//             </Box>
//           )}
//         </Box>
//       </Paper>

//       {/* Upload Options Section */}
//       <motion.div
//         initial={{ opacity: 0, y: 20 }}
//         animate={{ opacity: 1, y: 0 }}
//         transition={{ duration: 0.5 }}
//       >
//         <Paper
//           elevation={3}
//           sx={{
//             p: 3,
//             background: 'rgba(255, 255, 255, 0.9)',
//             border : '2px dashed #1976d2' ,
//             backdropFilter: 'blur(10px)',
//             borderRadius: 2,
//             transition: 'transform 0.3s ease',
//             '&:hover': {
//               transform: 'translateY(-5px)'
//             }
//           }}
//         >
//           <Typography 
//             variant="h6" 
//             sx={{ 
//               mb: 2,
//               background: 'linear-gradient(45deg, #2196F3 30%, #21CBF3 90%)',
//               WebkitBackgroundClip: 'text',
//               WebkitTextFillColor: 'transparent',
//               fontWeight: 'bold'
//             }}
//           >
//             Upload Options
//           </Typography>

//           <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
//             <motion.div
//               initial={{ opacity: 0, x: -20 }}
//               animate={{ opacity: 1, x: 0 }}
//               transition={{ delay: 0.2 }}
//             >
//               <FormControlLabel
//                 control={
//                   <Checkbox
//                     checked={options.requirePassword}
//                     onChange={handleOptionChange}
//                     name="requirePassword"
//                     color="primary"
//                   />
//                 }
//                 label="Require password for download"
//               />
//               <Collapse in={options.requirePassword}>
//                 <Box sx={{ pl: 4, pt: 2 }}>
//                   <TextField
//                     fullWidth
//                     margin="dense"
//                     name="password"
//                     label="Password"
//                     type={showPassword ? "text" : "password"}
//                     value={passwords.password}
//                     onChange={handlePasswordChange}
//                     InputProps={{
//                       endAdornment: (
//                         <InputAdornment position="end">
//                           <IconButton
//                             onClick={() => setShowPassword(!showPassword)}
//                             edge="end"
//                           >
//                             {showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}
//                           </IconButton>
//                         </InputAdornment>
//                       ),
//                     }}
//                   />
//                   <TextField
//                     fullWidth
//                     margin="dense"
//                     name="confirmPassword"
//                     label="Confirm Password"
//                     type="password"
//                     value={passwords.confirmPassword}
//                     onChange={handlePasswordChange}
//                     error={passwords.password !== passwords.confirmPassword}
//                     helperText={
//                       passwords.password !== passwords.confirmPassword 
//                         ? "Passwords don't match" 
//                         : ""
//                     }
//                   />
//                 </Box>
//               </Collapse>
//             </motion.div>

//             <motion.div
//               initial={{ opacity: 0, x: -20 }}
//               animate={{ opacity: 1, x: 0 }}
//               transition={{ delay: 0.3 }}
//             >
//               <FormControlLabel
//                 control={
//                   <Checkbox
//                     checked={options.showInWall}
//                     onChange={handleOptionChange}
//                     name="showInWall"
//                     color="primary"
//                   />
//                 }
//                 label="Show in Wall"
//               />
//             </motion.div>

//             <motion.div
//               initial={{ opacity: 0, x: -20 }}
//               animate={{ opacity: 1, x: 0 }}
//               transition={{ delay: 0.4 }}
//             >
//               <FormControlLabel
//                 control={
//                   <Checkbox
//                     checked={options.updateGit}
//                     onChange={handleOptionChange}
//                     name="updateGit"
//                     color="primary"
//                   />
//                 }
//                 label="Update Git Repository"
//               />
//               <Collapse in={options.updateGit}>
//                 <Box sx={{ pl: 4, pt: 2 }}>
//                   <TextField
//                     fullWidth
//                     margin="dense"
//                     name="username"
//                     label="GitHub Username"
//                     value={gitCredentials.username}
//                     onChange={handleGitCredentialsChange}
//                     InputProps={{
//                       startAdornment: (
//                         <InputAdornment position="start">
//                           <GitHubIcon />
//                         </InputAdornment>
//                       ),
//                     }}
//                   />
//                   <TextField
//                     fullWidth
//                     margin="dense"
//                     name="token"
//                     label="GitHub Token"
//                     type="password"
//                     value={gitCredentials.token}
//                     onChange={handleGitCredentialsChange}
//                   />
//                 </Box>
//               </Collapse>
//             </motion.div>
//           </Box>
//         </Paper>
//       </motion.div>
//     </Box>
//   );
// }

// export default DropZoneArea;


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// src/components/DropZoneArea.js
// import React, { useCallback } from 'react';
// import { Box, Typography, Paper, Container } from '@mui/material';
// import { useDropzone } from 'react-dropzone';
// import CloudUploadIcon from '@mui/icons-material/CloudUpload';
// import SettingsIcon from '@mui/icons-material/Settings';
// import { styled } from '@mui/material/styles';
// import FormControlLabel from '@mui/material/FormControlLabel';
// import Checkbox from '@mui/material/Checkbox';
// import TextField from '@mui/material/TextField';
// import Collapse from '@mui/material/Collapse';
// import InputAdornment from '@mui/material/InputAdornment';
// import IconButton from '@mui/material/IconButton';
// import VisibilityIcon from '@mui/icons-material/Visibility';
// import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
// import GitHubIcon from '@mui/icons-material/GitHub';

// import axios from 'axios';
// import './DropZoneArea.css'


// const StyledPaper = styled(Paper)(({ theme }) => ({
//   padding: theme.spacing(4),
//   borderRadius: theme.spacing(2),
//   textAlign: 'center',
//   backgroundColor: theme.palette.background.paper,
//   minHeight: 250,
//   display: 'flex',
//   flexDirection: 'column',
//   justifyContent: 'center',
//   alignItems: 'center',
//   transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
//   cursor: 'pointer',
//   '&:hover': {
//     transform: 'translateY(-5px)',
//     boxShadow: theme.shadows[10],
//   },
// }));





// function DropZoneArea({ onFileUpload }) {
//   const [showPassword, setShowPassword] = React.useState(false);
//   const [options, setOptions] = React.useState({
//     requirePassword: false,
//     showInWall: false,
//     updateGit: false,
//   });
//   const [passwords, setPasswords] = React.useState({
//     password: '',
//     confirmPassword: '',
//   });
//   const [gitCredentials, setGitCredentials] = React.useState({
//     username: '',
//     token: '',
//   });

//   const handleOptionChange = (event) => {
//     setOptions({
//       ...options,
//       [event.target.name]: event.target.checked,
//     });
//   };

//   const handlePasswordChange = (event) => {
//     setPasswords({
//       ...passwords,
//       [event.target.name]: event.target.value,
//     });
//   };

//   const handleGitCredentialsChange = (event) => {
//     setGitCredentials({
//       ...gitCredentials,
//       [event.target.name]: event.target.value,
//     });
//   };

//   // const onDrop = useCallback((acceptedFiles) => {
//   //   onFileUpload(acceptedFiles);
//   // }, [onFileUpload]);

//   // const { getRootProps, getInputProps, isDragActive } = useDropzone({
//   //   onDrop,
//   //   accept: {
//   //     'application/vnd.android.package-archive': ['.apk'],
//   //     'application/x-ios-app': ['.ipa'],
//   //     'application/zip': ['.zip'],
//   //   },
//   //   maxSize: 100 * 1024 * 1024,
//   // });


//   const onDrop = async (acceptedFiles) => {
//   const file = acceptedFiles[0]; // assuming single file

//   const formData = new FormData();
//   formData.append('file', file); // Your API may expect 'file' as the field name

//   try {
//     const response = await axios.post(
//       'http://localhost:5065/api/Apps/upload-apk',
//       formData,
//       {
//         headers: {
//           'Content-Type': 'multipart/form-data',
//         },
//       }
//     );
//     console.log('Upload success:', response.data);
//     // Show success UI or toast
//   } catch (error) {
//     console.error('Upload error:', error);
//     // Show error UI or toast
//   }
// };

// const { getRootProps, getInputProps, isDragActive } = useDropzone({
//   onDrop,
//   multiple: false, // optional: allow only one file
//   accept: {
//     'application/vnd.android.package-archive': ['.apk','.zip'] // only APKs
//   }
// });

//   return (
//     <Container maxWidth="lg">
//       <Box sx={{ 
//         display: 'flex', 
//         flexDirection: 'column',
//         gap: 4, 
//         p: 3,
        
        
//         position: 'relative'
//       }}>
//         {/* File Upload Box */}
//         {/* <StyledPaper 
//           elevation={3}
//           className="block"
//           sx={{
//             cursor: 'pointer',
//             p: 3,
//             background: isDragActive ? 'rgba(25, 118, 210, 0.1)' : 'rgba(255, 255, 255, 0.9)',
//             border: '2px dashed #1976d2',
//           }}
          
//         >
//           <Box
//             {...getRootProps()}
//             sx={{
//               width: '100%',
//               height: '100%',
//               display: 'flex',
//               flexDirection: 'column',
//               justifyContent: 'center',
              
              
//               alignItems: 'center'
//             }}
//           >
//             <input {...getInputProps()} />
//             <CloudUploadIcon sx={{ fontSize: 60, color: isDragActive ? '#1976d2' : '#757575' }} />
//             <Typography 
//               variant="h6" 
//               gutterBottom
//               sx={{ fontWeight: 600 }}
//             >
//               Share Your Files
//             </Typography>
//             <Typography 
//               variant="body2" 
//               color="text.secondary"
//               sx={{ maxWidth: '80%', margin: '0 auto' }}
//             >
//               Drag and drop files here or click to browse
//             </Typography>
//           </Box>
//         </StyledPaper> */}

//         <StyledPaper
//   elevation={3}
//   className="block"
//   sx={{
//     cursor: 'pointer',
//     p: 3,
//     background: isDragActive ? 'rgba(25, 118, 210, 0.1)' : 'rgba(255, 255, 255, 0.9)',
//     border: '2px dashed #1976d2',
//   }}
// >
//   <Box
//     {...getRootProps()}
//     sx={{
//       width: '100%',
//       height: '100%',
//       display: 'flex',
//       flexDirection: 'column',
//       justifyContent: 'center',
//       alignItems: 'center',
//     }}
//   >
//     <input {...getInputProps()} />
//     <CloudUploadIcon sx={{ fontSize: 60, color: isDragActive ? '#1976d2' : '#757575' }} />
//     <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
//       Share Your Files
//     </Typography>
//     <Typography
//       variant="body2"
//       color="text.secondary"
//       sx={{ maxWidth: '80%', margin: '0 auto' }}
//     >
//       Drag and drop APK file here or click to browse
//     </Typography>
//   </Box>
// </StyledPaper>


//         {/* Upload Options Box */}
//         <StyledPaper 
//           elevation={3}
//           className="block"
//           sx={{
//             cursor: 'default',
//             p: 3,
//             background: 'rgba(255, 255, 255, 0.9)',
//             border: '2px dashed #1976d2'
//           }}
//         >
//           <Typography 
//             variant="h6" 
//             sx={{ 
//               mb: 2,
//               background: 'linear-gradient(45deg, #2196F3 30%, #21CBF3 90%)',
//               WebkitBackgroundClip: 'text',
//               WebkitTextFillColor: 'transparent',
//               fontWeight: 'bold'
//             }}
//           >
//             Upload Options
//           </Typography>

//           <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
//             {/* Password Option */}
//             <FormControlLabel
//               control={
//                 <Checkbox
//                   checked={options.requirePassword}
//                   onChange={handleOptionChange}
//                   name="requirePassword"
//                   color="primary"
//                 />
//               }
//               label="Require password for download"
//             />
//             <Collapse in={options.requirePassword}>
//               <Box sx={{ pl: 4, pt: 2 }}>
//                 <TextField
//                   fullWidth
//                   margin="dense"
//                   name="password"
//                   label="Password"
//                   type={showPassword ? "text" : "password"}
//                   value={passwords.password}
//                   onChange={handlePasswordChange}
//                   InputProps={{
//                     endAdornment: (
//                       <InputAdornment position="end">
//                         <IconButton
//                           onClick={() => setShowPassword(!showPassword)}
//                           edge="end"
//                         >
//                           {showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}
//                         </IconButton>
//                       </InputAdornment>
//                     ),
//                   }}
//                 />
//                 <TextField
//                   fullWidth
//                   margin="dense"
//                   name="confirmPassword"
//                   label="Confirm Password"
//                   type="password"
//                   value={passwords.confirmPassword}
//                   onChange={handlePasswordChange}
//                   error={passwords.password !== passwords.confirmPassword}
//                   helperText={
//                     passwords.password !== passwords.confirmPassword 
//                       ? "Passwords don't match" 
//                       : ""
//                   }
//                 />
//               </Box>
//             </Collapse>

//             {/* Show in Wall Option */}
//             <FormControlLabel
//               control={
//                 <Checkbox
//                   checked={options.showInWall}
//                   onChange={handleOptionChange}
//                   name="showInWall"
//                   color="primary"
//                 />
//               }
//               label="Show in Wall"
//             />

//             {/* Git Repository Option */}
//             <FormControlLabel
//               control={
//                 <Checkbox
//                   checked={options.updateGit}
//                   onChange={handleOptionChange}
//                   name="updateGit"
//                   color="primary"
//                 />
//               }
//               label="Update Git Repository"
//             />
//             <Collapse in={options.updateGit}>
//               <Box sx={{ pl: 4, pt: 2 }}>
//                 <TextField
//                   fullWidth
//                   margin="dense"
//                   name="username"
//                   label="GitHub Username"
//                   value={gitCredentials.username}
//                   onChange={handleGitCredentialsChange}
//                   InputProps={{
//                     startAdornment: (
//                       <InputAdornment position="start">
//                         <GitHubIcon />
//                       </InputAdornment>
//                     ),
//                   }}
//                 />
//                 <TextField
//                   fullWidth
//                   margin="dense"
//                   name="token"
//                   label="GitHub Token"
//                   type="password"
//                   value={gitCredentials.token}
//                   onChange={handleGitCredentialsChange}
//                 />
//               </Box>
//             </Collapse>
//           </Box>
//         </StyledPaper>

//         {/* Drag Active Overlay */}
//         {isDragActive && (
//           <Box
//             sx={{
//               position: 'absolute',
//               top: 0,
//               left: 0,
//               right: 0,
//               bottom: 0,
//               backgroundColor: 'rgba(25, 118, 210, 0.1)',
//               zIndex: 1,
//               display: 'flex',
//               justifyContent: 'center',
//               alignItems: 'center',
//               borderRadius: 2,
//               border: '2px dashed #1976d2'
//             }}
//           >
//             <Typography 
//               variant="h6" 
//               color="primary"
//               sx={{ 
//                 backgroundColor: 'rgba(255, 255, 255, 0.9)',
//                 padding: '1rem 2rem',
//                 borderRadius: '8px'
//               }}
//             >
//               Drop files here...
//             </Typography>
//           </Box>
//         )}
//       </Box>
//     </Container>
//   );
// }

// export default DropZoneArea;

////////////////////////////////////////////////////////////////////////////////////////////////////////

import React, { useCallback, useState } from 'react';
import {
  Box, Typography, Paper, Container, Snackbar, Button,
  Collapse, TextField, InputAdornment, IconButton, FormControlLabel, Checkbox, Tooltip
} from '@mui/material';
import { useDropzone } from 'react-dropzone';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import GitHubIcon from '@mui/icons-material/GitHub';
import FileCopyIcon from '@mui/icons-material/FileCopy';
import ShareIcon from '@mui/icons-material/Share';
import { styled } from '@mui/material/styles';
import axios from 'axios';
import QRCode from 'react-qr-code';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import { useUploadStore } from '../../store/useUploadStore';
import { useNavigate } from 'react-router-dom';

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  borderRadius: theme.spacing(2),
  textAlign: 'center',
  backgroundColor: theme.palette.background.paper,
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
  cursor: 'pointer',
  '&:hover': {
    transform: 'translateY(-5px)',
    boxShadow: theme.shadows[10],
  },
}));

function DropZoneArea() {
  const [showPassword, setShowPassword] = useState(false);
  const [options, setOptions] = useState({ requirePassword: false, showInWall: false, updateGit: false });
  const [passwords, setPasswords] = useState({ password: '', confirmPassword: '' });
  const [gitCredentials, setGitCredentials] = useState({ username: '', token: '' });
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [uploadResult, setUploadResult] = useState(null);
  const [uploading, setUploading] = useState(false);
  const setUploadedFile = useUploadStore((state) => state.setUploadedFile);
const navigate = useNavigate();


  const handleOptionChange = (e) => {
    setOptions({ ...options, [e.target.name]: e.target.checked });
  };

  const handlePasswordChange = (e) => {
    setPasswords({ ...passwords, [e.target.name]: e.target.value });
  };

  const handleGitCredentialsChange = (e) => {
    setGitCredentials({ ...gitCredentials, [e.target.name]: e.target.value });
  };

//   const onDrop = async (acceptedFiles) => {
//   const file = acceptedFiles[0];
//   const formData = new FormData();
//   formData.append('file', file);

//   try {
//     setUploading(true); // Show loader
//     const response = await axios.post('http://localhost:5065/api/Apps/upload-apk', formData, {
//       headers: { 'Content-Type': 'multipart/form-data' },
//     });

//     setUploadResult(response.data);
//     setSnackbarOpen(true);
//   } catch (error) {
//     console.error('Upload failed:', error);
//     alert("Upload failed! Check the console.");
//   } finally {
//     setUploading(false); // Hide loader
//   }
// };


const onDrop = async (acceptedFiles) => {
  const file = acceptedFiles[0];


  // Upload to your API
  const formData = new FormData();
  formData.append('file', file);

  try {
setUploading(true); 
    const response = await axios.post('http://localhost:5065/api/Apps/upload-apk', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });

    setUploadedFile(file);  // Store in zustand
setUploadResult(response.data);
    setSnackbarOpen(true);
  } catch (error) {
    console.error('Upload failed:', error);
    alert("Upload failed! Check the console.");
  } finally {
    setUploading(false); // Hide loader
  }
};

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: false,
    accept: { 'application/vnd.android.package-archive': ['.apk'], 'application/zip': ['.zip'] },
  });

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <Container maxWidth="lg">
      <Backdrop sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }} open={uploading}>
  <CircularProgress color="inherit" />
</Backdrop>
      <Box sx={{ p: 3, display: 'flex', flexDirection: 'column', gap: 4, position: 'relative' }}>
        <StyledPaper elevation={3} sx={{ border: '2px dashed #1976d2', background: isDragActive ? 'rgba(25, 118, 210, 0.1)' : 'rgba(255,255,255,0.9)' }}>
          <Box {...getRootProps()} sx={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <input {...getInputProps()} />
            <CloudUploadIcon sx={{ fontSize: 60, color: isDragActive ? '#1976d2' : '#757575' }} />
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>Share Your Files</Typography>
            <Typography variant="body2" color="text.secondary">Drag & drop or click to upload an APK or ZIP file</Typography>
          </Box>
        </StyledPaper>

        <StyledPaper elevation={3} sx={{ border: '2px dashed #1976d2' }}>
          <Typography variant="h6" sx={{
            background: 'linear-gradient(45deg, #2196F3 30%, #21CBF3 90%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            fontWeight: 'bold'
          }}>Upload Options</Typography>

          <Box sx={{ mt: 2 }}>
            <FormControlLabel
              control={<Checkbox checked={options.requirePassword} onChange={handleOptionChange} name="requirePassword" />}
              label="Require password for download"
            />
            <Collapse in={options.requirePassword}>
              <TextField fullWidth margin="dense" name="password" label="Password" type={showPassword ? 'text' : 'password'} value={passwords.password} onChange={handlePasswordChange}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => setShowPassword(!showPassword)}>{showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}</IconButton>
                    </InputAdornment>
                  ),
                }}
              />
              <TextField fullWidth margin="dense" name="confirmPassword" label="Confirm Password" type="password" value={passwords.confirmPassword} onChange={handlePasswordChange}
                error={passwords.password !== passwords.confirmPassword}
                helperText={passwords.password !== passwords.confirmPassword ? "Passwords don't match" : ""}
              />
            </Collapse>

            <FormControlLabel
              control={<Checkbox checked={options.showInWall} onChange={handleOptionChange} name="showInWall" />}
              label="Show in Wall"
            />

            <FormControlLabel
              control={<Checkbox checked={options.updateGit} onChange={handleOptionChange} name="updateGit" />}
              label="Update Git Repository"
            />
            <Collapse in={options.updateGit}>
              <TextField fullWidth margin="dense" name="username" label="GitHub Username" value={gitCredentials.username} onChange={handleGitCredentialsChange}
                InputProps={{ startAdornment: (<InputAdornment position="start"><GitHubIcon /></InputAdornment>) }}
              />
              <TextField fullWidth margin="dense" name="token" label="GitHub Token" type="password" value={gitCredentials.token} onChange={handleGitCredentialsChange} />
            </Collapse>
          </Box>
        </StyledPaper>

        {/* Upload Result */}
        {uploadResult && (
          <StyledPaper elevation={3} sx={{ animation: 'fadeIn 0.6s ease' }}>
            <Typography variant="h6" gutterBottom>Upload Successful!</Typography>
            <Typography variant="body1" sx={{ wordWrap: 'break-word' }}>
              <strong>Download Link:</strong><br />
              <a href={uploadResult.downloadUrl} target="_blank" rel="noreferrer">{uploadResult.downloadUrl}</a>
            </Typography>

            <Box mt={2} sx={{ display: 'flex', gap: 2, justifyContent: 'center' }}>
              <Tooltip title="Copy Link">
                <IconButton onClick={() => copyToClipboard(uploadResult.downloadUrl)}>
                  <FileCopyIcon />
                </IconButton>
              </Tooltip>
              <Tooltip title="Share">
                <IconButton onClick={() => navigator.share?.({ url: uploadResult.downloadUrl })}>
                  <ShareIcon />
                </IconButton>
              </Tooltip>
            </Box>

            <Box mt={4}>
              <Typography variant="body1"><strong>QR Code:</strong></Typography>
              <Box sx={{ mt: 2, background: '#fff', p: 2, borderRadius: 2 }}>
                <QRCode value={uploadResult.downloadUrl} size={180} />
              </Box>
            </Box>
          </StyledPaper>
        )}

        <Snackbar open={snackbarOpen} autoHideDuration={4000} onClose={() => setSnackbarOpen(false)} message="File uploaded successfully!" />
      </Box>
    </Container>
  );
}

export default DropZoneArea;
