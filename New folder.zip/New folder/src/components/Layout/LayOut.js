// src/components/Layout/Layout.js
import React from 'react';
import Header from './Header';
import Footer from './Footer';
import DropZoneArea from '../DropZoneArea/DropZoneArea';
import Chatbot from '../../ChatBot/chatBot';
import { Container, Paper, Typography, Box , Button} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import ChatIcon from '@mui/icons-material/Chat';
import FloatingButton from '../FloatingButton/FloatingButton';
import Features from '../Features';
import './LayOut.css';

function Layout() {

      const navigate = useNavigate();

    // Fix the handleChatbotClick function
    const handleChatbotClick = () => {
        navigate('/chatbot'); // Navigate to the chatbot route
    };
  return (
    <div className="container">
      <div className="section header-section">
        {/* <FloatingButton /> */}
        <Header />
        
      </div>
      
      
      <div className="section content-section">
        <Container maxWidth="md" sx={{ py: 4 }}>
          <Paper 
            elevation={0} 
            sx={{ 
              p: 3, 
              backgroundColor: 'transparent',
              animation: 'appear linear',
              animationTimeline: 'view()',
              animationRange: 'entry 0% cover 40%'
            }}
          >
            <Typography 
              variant="h4" 
              component="h2" 
              gutterBottom 
              align="center"
              sx={{ mb: 4 }}
            >
              Share Your Files
            </Typography>
         
            
            
            <Box sx={{ 
              maxWidth: 600, 
              mx: 'auto',
              animation: 'appear linear',
              animationTimeline: 'view()',
              animationRange: 'entry 0% cover 40%'
            }}>
              <DropZoneArea />
            </Box>

            {/* Optional: Add recent uploads or file list section */}
           
          </Paper>
        </Container>
      </div>
      <Features />
      
      <div className="section footer-section">
        <Footer />
      </div>
    </div>
  );
}

export default Layout;
