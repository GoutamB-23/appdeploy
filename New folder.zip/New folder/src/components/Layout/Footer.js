// src/components/Layout/Footer.js
import React from 'react';
import { Box, Container, Grid, Typography, Link, IconButton, Paper } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import GitHubIcon from '@mui/icons-material/GitHub';
import TwitterIcon from '@mui/icons-material/Twitter';
import AppsIcon from '@mui/icons-material/Apps';
import ShareIcon from '@mui/icons-material/Share';
import VisibilityIcon from '@mui/icons-material/Visibility';
import SecurityIcon from '@mui/icons-material/Security';

import './LayOut.css';

function Footer() {
  const theme = useTheme();

  return (
    <footer id="footer-section">
    <Box
      component="footer"
      sx={{
        backgroundColor: theme.palette.mode === 'dark' ? '#1A1A1A' : '#f5f5f5',
        color: theme.palette.text.primary,
        py: 6,
        borderTop: `1px solid ${theme.palette.divider}`,
      }}
    >
      <Container maxWidth="lg">
        <Grid container spacing={4} sx={{ mb: 4 }}>
          {/* Details Block */}
          <Grid item xs={12} md={6} className="footer-block">
            <Paper 
              elevation={3}
              sx={{
                p: 3,
                height: '100%',
                backgroundColor: theme.palette.mode === 'dark' ? '#242424' : '#ffffff',
                transition: 'all 0.3s ease',
              }}
            >
              <Typography variant="h5" gutterBottom sx={{ 
                borderBottom: `2px solid ${theme.palette.primary.main}`,
                pb: 1,
                mb: 3
              }}>
                About Us
              </Typography>
              <Box className="footer-animate">
                <Typography variant="body1" paragraph>
                  Our file sharing application provides a secure and efficient way to share
                  files across devices. With end-to-end encryption and real-time syncing,
                  your data remains safe and accessible whenever you need it.
                </Typography>
                <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>
                  Features:
                </Typography>
                <Box sx={{ pl: 2 }}>
                  <Typography component="li" variant="body1" sx={{ mb: 1 }}>
                    ⚡ Secure file sharing with end-to-end encryption
                  </Typography>
                  <Typography component="li" variant="body1" sx={{ mb: 1 }}>
                    🔄 Real-time synchronization across devices
                  </Typography>
                  <Typography component="li" variant="body1" sx={{ mb: 1 }}>
                    💻 Cross-platform compatibility
                  </Typography>
                  <Typography component="li" variant="body1">
                    ☁️ Cloud storage integration
                  </Typography>
                </Box>
              </Box>
            </Paper>
          </Grid>

          {/* Contact Block */}
         <Grid item xs={12} md={6} className="footer-block">
  <Paper
    elevation={3}
    sx={{
      p: 3,
      height: '100%',
      backgroundColor: theme.palette.mode === 'dark' ? '#242424' : '#ffffff',
      transition: 'all 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    }}
  >
    <Typography
      variant="h5"
      gutterBottom
      sx={{
        borderBottom: `2px solid ${theme.palette.primary.main}`,
        pb: 1,
        mb: 3,
      }}
    >
      Wall Of Apps
    </Typography>

    <Box
      className="footer-animate"
      sx={{
        width: '100%',
        flexGrow: 1,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        height: '100%',
      }}
    >
      {/* Contact Details */}
      <Box sx={{ mb: 4, width: '100%' }}>
  {[
    {
      icon: <AppsIcon sx={{ mr: 2, color: theme.palette.primary.main }} />,
      text: 'Access the Wall of Apps to discover shared applications from other users.',
    },
    {
      icon: <ShareIcon sx={{ mr: 2, color: theme.palette.primary.main }} />,
      text: 'Easily share your own app or file to the Wall with a single click.',
    },
    {
      icon: <VisibilityIcon sx={{ mr: 2, color: theme.palette.primary.main }} />,
      text: 'View app details like name, platform, uploader, and download count.',
    },
    {
      icon: <SecurityIcon sx={{ mr: 2, color: theme.palette.primary.main }} />,
      text: 'You control your sharing — opt in before your app appears on the Wall.',
    },
  ].map(({ icon, text }, index) => (
    <Box
      key={index}
      sx={{
        display: 'flex',
        alignItems: 'center',
        mb: index !== 3 ? 2 : 0,
        cursor: 'pointer',
        '&:hover': {
          transform: 'translateX(10px)',
          transition: 'transform 0.3s ease',
          color: theme.palette.primary.main,
        },
      }}
    >
      {icon}
      <Typography variant="body1">{text}</Typography>
    </Box>
  ))}
</Box>


      {/* Social Media Links */}
      {/* <Box sx={{ width: '100%' }}>
        <Typography variant="h6" gutterBottom>
          Connect With Us
        </Typography>
        <Box
          sx={{
            display: 'flex',
            gap: 2,
            mt: 2,
          }}
        >
          {[LinkedInIcon, GitHubIcon, TwitterIcon].map((IconComponent, index) => (
            <IconButton
              key={index}
              aria-label={IconComponent.displayName || `icon-${index}`}
              sx={{
                color: theme.palette.primary.main,
                '&:hover': {
                  transform: 'scale(1.1)',
                  backgroundColor: theme.palette.primary.main,
                  color: 'white',
                },
                transition: 'all 0.3s ease',
              }}
            >
              <IconComponent />
            </IconButton>
          ))}
        </Box>
      </Box> */}
    </Box>
  </Paper>
</Grid>

         <Grid item xs={12} md={6} className="footer-block">
  <Paper
    elevation={3}
    sx={{
      p: 3,
      height: '100%',
      backgroundColor: theme.palette.mode === 'dark' ? '#242424' : '#ffffff',
      transition: 'all 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    }}
  >
    <Typography
      variant="h5"
      gutterBottom
      sx={{
        borderBottom: `2px solid ${theme.palette.primary.main}`,
        pb: 1,
        mb: 3,
      }}
    >
      Contact Us
    </Typography>

    <Box
      className="footer-animate"
      sx={{
        width: '100%',
        flexGrow: 1,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        height: '100%',
      }}
    >
      {/* Contact Details */}
      <Box sx={{ mb: 4, width: '100%' }}>
        {[
          {
            icon: <EmailIcon sx={{ mr: 2, color: theme.palette.primary.main }} />,
            text: 'Email: contact@filesharing.com',
          },
          {
            icon: <PhoneIcon sx={{ mr: 2, color: theme.palette.primary.main }} />,
            text: 'Phone: +1 (555) 123-4567',
          },
          {
            icon: <LocationOnIcon sx={{ mr: 2, color: theme.palette.primary.main }} />,
            text: '123 File Street, Cloud City, DC 10001',
          },
        ].map(({ icon, text }, index) => (
          <Box
            key={index}
            sx={{
              display: 'flex',
              alignItems: 'center',
              mb: index !== 2 ? 2 : 0,
              cursor: 'pointer',
              '&:hover': {
                transform: 'translateX(10px)',
                transition: 'transform 0.3s ease',
                color: theme.palette.primary.main,
              },
            }}
          >
            {icon}
            <Typography variant="body1">{text}</Typography>
          </Box>
        ))}
      </Box>

      {/* Social Media Links */}
      <Box sx={{ width: '100%' }}>
        <Typography variant="h6" gutterBottom>
          Connect With Us
        </Typography>
        <Box
          sx={{
            display: 'flex',
            gap: 2,
            mt: 2,
          }}
        >
          {[LinkedInIcon, GitHubIcon, TwitterIcon].map((IconComponent, index) => (
            <IconButton
              key={index}
              aria-label={IconComponent.displayName || `icon-${index}`}
              sx={{
                color: theme.palette.primary.main,
                '&:hover': {
                  transform: 'scale(1.1)',
                  backgroundColor: theme.palette.primary.main,
                  color: 'white',
                },
                transition: 'all 0.3s ease',
              }}
            >
              <IconComponent />
            </IconButton>
          ))}
        </Box>
      </Box>
    </Box>
  </Paper>
</Grid>





        </Grid>

        {/* Copyright Section */}
        <Box 
          className="footer-animate"
          sx={{ 
            mt: 4, 
            pt: 3, 
            borderTop: `1px solid ${theme.palette.divider}`,
            textAlign: 'center'
          }}
        >
          <Typography variant="body2" color="text.secondary">
            © {new Date().getFullYear()} File Sharing App. All rights reserved.
          </Typography>
          <Box sx={{ mt: 1 }}>
            <Link href="#" color="inherit" sx={{ mx: 2 }}>
              Privacy Policy
            </Link>
            <Link href="#" color="inherit" sx={{ mx: 2 }}>
              Terms of Service
            </Link>
            <Link href="#" color="inherit" sx={{ mx: 2 }}>
              Cookie Policy
            </Link>
          </Box>
        </Box>
      </Container>
    </Box>
    </footer>
  );
}

export default Footer;
