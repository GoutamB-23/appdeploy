// src/components/LandingPage/assets/svgs.js

export const DoodleElements = [
  {
    id: 'star',
    component: (
      <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
        <path d="M20 0L24.4903 15.5097L40 20L24.4903 24.4903L20 40L15.5097 24.4903L0 20L15.5097 15.5097L20 0Z" 
          fill="#88CE02"/>
      </svg>
    ),
    position: { top: '20%', left: '15%' }
  },
  {
    id: 'circle',
    component: (
      <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
        <circle cx="20" cy="20" r="15" stroke="#00B8FF" strokeWidth="2"/>
      </svg>
    ),
    position: { top: '25%', right: '20%' }
  },
  {
    id: 'square',
    component: (
      <svg width="35" height="35" viewBox="0 0 35 35" fill="none">
        <rect x="5" y="5" width="25" height="25" stroke="#FF3366" strokeWidth="2"/>
      </svg>
    ),
    position: { bottom: '30%', left: '25%' }
  },
  {
    id: 'dots',
    component: (
      <svg width="60" height="20" viewBox="0 0 60 20" fill="none">
        <circle cx="10" cy="10" r="4" fill="#88CE02"/>
        <circle cx="30" cy="10" r="4" fill="#00B8FF"/>
        <circle cx="50" cy="10" r="4" fill="#FF3366"/>
      </svg>
    ),
    position: { top: '35%', right: '30%' }
  },
  {
    id: 'zigzag',
    component: (
      <svg width="70" height="20" viewBox="0 0 70 20" fill="none">
        <path d="M0 10L20 0L40 20L60 0" stroke="#88CE02" strokeWidth="2"/>
      </svg>
    ),
    position: { bottom: '25%', right: '15%' }
  },
  {
    id: 'plus',
    component: (
      <svg width="30" height="30" viewBox="0 0 30 30" fill="none">
        <path d="M15 0V30M0 15H30" stroke="#00B8FF" strokeWidth="2"/>
      </svg>
    ),
    position: { top: '40%', left: '20%' }
  }
];

export const GradientDefs = () => (
  <svg width="0" height="0">
    <defs>
      <linearGradient id="mainGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#88CE02" />
        <stop offset="100%" stopColor="#00B8FF" />
      </linearGradient>
    </defs>
  </svg>
);
