import React, { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Button, Container, Typography } from '@mui/material';
import gsap from 'gsap';
import { ScrambleTextPlugin } from 'gsap/ScrambleTextPlugin';

gsap.registerPlugin(ScrambleTextPlugin);

const LandingPage = () => {
  const navigate = useNavigate();
  const textRef = useRef(null);
  const mainTextRef = useRef(null);
  const buttonRef = useRef(null);
  const containerRef = useRef(null);

  const handleGetStarted = () => {
    gsap.to([textRef.current, mainTextRef.current, buttonRef.current], {
      opacity: 0,
      y: -30,
      duration: 0.5,
      ease: "power2.inOut",
      stagger: 0.1,
      onComplete: () => navigate('/home')
    });
  };

  useEffect(() => {
    const mainTl = gsap.timeline();

    mainTl
      .to(textRef.current, {
        duration: 1.5,
        scrambleText: {
          text: "SecureShare",
          chars: "lowerCase",
          speed: 0.3
        }
      })
      .to(mainTextRef.current, {
        opacity: 1,
        y: 0,
        duration: 1,
        ease: "power2.out"
      })
      .to(buttonRef.current, {
        opacity: 1,
        duration: 1
      });

    return () => mainTl.kill();
  }, []);

  return (
    <Box
      ref={containerRef}
      sx={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        background: '#ffffff',
        position: 'relative',
        overflow: 'hidden',
        '&::before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: `
            linear-gradient(45deg, rgba(33, 150, 243, 0.03) 25%, transparent 25%),
            linear-gradient(-45deg, rgba(33, 150, 243, 0.03) 25%, transparent 25%),
            linear-gradient(45deg, transparent 75%, rgba(33, 150, 243, 0.03) 75%),
            linear-gradient(-45deg, transparent 75%, rgba(33, 150, 243, 0.03) 75%)
          `,
          backgroundSize: '20px 20px',
          backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px',
          zIndex: 0
        }
      }}
    >
      <Container 
        maxWidth="md"
        sx={{
          position: 'relative',
          zIndex: 1,
          textAlign: 'center',
          px: 3
        }}
      >
        <Box sx={{ mb: 8 }}>
          <Typography
            ref={textRef}
            variant="h1"
            sx={{
              fontSize: { xs: '2.5rem', sm: '3.5rem', md: '4.5rem' },
              fontWeight: 700,
              color: '#1a1a1a',
              mb: 2
            }}
          >
            &nbsp;
          </Typography>

          <Typography
            ref={mainTextRef}
            variant="h4"
            sx={{
              mt: 3,
              color: '#666666',
              fontSize: { xs: '1.2rem', sm: '1.5rem', md: '1.8rem' },
              fontWeight: 300,
              opacity: 0,
              transform: 'translateY(20px)'
            }}
          >
            Share Your Files Securely
          </Typography>

          <Box 
            ref={buttonRef}
            sx={{ 
              mt: 4,
              opacity: 0
            }}
          >
            <Button
              variant="contained"
              size="large"
              onClick={handleGetStarted}
              sx={{
                px: 6,
                py: 2,
                fontSize: { xs: '1rem', sm: '1.1rem' },
                borderRadius: '8px',
                background: 'linear-gradient(45deg, #2196F3 30%, #21CBF3 90%)',
                color: 'white',
                boxShadow: '0 3px 15px rgba(33, 150, 243, 0.3)',
                transition: 'all 0.3s ease',
                '&:hover': {
                  transform: 'translateY(-2px)',
                  boxShadow: '0 5px 20px rgba(33, 150, 243, 0.4)'
                }
              }}
            >
              Get Started
            </Button>
          </Box>
        </Box>
      </Container>
    </Box>
  );
};

export default LandingPage;
