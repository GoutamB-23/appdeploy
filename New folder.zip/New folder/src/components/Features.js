// src/components/Features/Features.js
import React from 'react';
import { styled } from '@mui/system';
import { Box, Grid, Typography, Card, Container } from '@mui/material';

// Icons for features
const FeatureIcon = ({ children }) => (
  <svg 
    width="40" 
    height="40" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
  >
    {children}
  </svg>
);

// Add this with your other styled components
const SectionTitle = styled(Typography)({
  position: 'relative',
  marginBottom: '3rem',
  fontWeight: 700,
  '&::after': {
    content: '""',
    position: 'absolute',
    bottom: '-10px',
    left: '50%',
    transform: 'translateX(-50%)',
    width: '60px',
    height: '4px',
    background: 'linear-gradient(90deg, #2196F3, #21CBF3)',
    borderRadius: '2px',
  },
});

// Feature icons definitions
const icons = {
  multiPlatform: (
    <FeatureIcon>
      <path d="M21 10v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V10" />
      <path d="M17 6V4a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v2" />
      <line x1="12" y1="11" x2="12" y2="17" />
      <line x1="9" y1="14" x2="15" y2="14" />
    </FeatureIcon>
  ),
  dragDrop: (
    <FeatureIcon>
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" y1="3" x2="12" y2="15" />
    </FeatureIcon>
  ),
  oneClick: (
    <FeatureIcon>
      <circle cx="12" cy="12" r="10" />
      <path d="M8 14s1.5 2 4 2 4-2 4-2" />
      <line x1="9" y1="9" x2="9.01" y2="9" />
      <line x1="15" y1="9" x2="15.01" y2="9" />
    </FeatureIcon>
  ),
  security: (
    <FeatureIcon>
      <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
      <path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </FeatureIcon>
  ),
  compatibility: (
    <FeatureIcon>
      <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
      <line x1="8" y1="21" x2="16" y2="21" />
      <line x1="12" y1="17" x2="12" y2="21" />
    </FeatureIcon>
  ),
  premium: (
    <FeatureIcon>
      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
    </FeatureIcon>
  ),
};

const features = [
  {
    title: 'Multi-Platform Support',
    description: 'Compatible with iOS 4+ and Android 2+ apps and devices. Support for development, ad-hoc and in-house builds.',
    icon: 'multiPlatform',
  },
  {
    title: 'Easy Upload',
    description: 'Simply drag & drop your IPA, zipped .APP or APK files to get an instant sharing link.',
    icon: 'dragDrop',
  },
  {
    title: 'One-Tap Installation',
    description: 'Users can download and install apps with a single tap on their mobile devices.',
    icon: 'oneClick',
  },
  {
    title: 'Private & Secure',
    description: 'Private links with no search indexing, optional password protection, and full compliance with Apple security rules.',
    icon: 'security',
  },
  {
    title: 'Device Compatibility',
    description: 'Automatic UDID retrieval and device compatibility checking tools included.',
    icon: 'compatibility',
  },
  {
    title: 'Premium Features',
    description: 'Access to custom URLs, APIs, statistics, no expiration dates, and more with a premium account.',
    icon: 'premium',
  },
];

// Update the styling for a more modern look
const FeatureCard = styled(Card)(({ theme }) => ({
  padding: '1.5rem',
  transition: 'all 0.3s ease-in-out',
  background: 'rgba(255, 255, 255, 0.8)',
  backdropFilter: 'blur(10px)',
  border: '1px solid rgba(255, 255, 255, 0.3)',
  boxShadow: '0 4px 30px rgba(0, 0, 0, 0.1)',
  borderRadius: '16px',
  '&:hover': {
    transform: 'translateX(5px)',
    boxShadow: '0 8px 40px rgba(0, 0, 0, 0.1)',
    background: 'rgba(255, 255, 255, 0.95)',
    '& .icon-wrapper': {
      transform: 'scale(1.1)',
      color: '#1976d2',
    },
  },
}));

const IconWrapper = styled(Box)({
  marginRight: '1rem',
  color: '#2196F3',
  padding: '0.75rem',
  borderRadius: '12px',
  background: 'rgba(33, 150, 243, 0.1)',
  transition: 'all 0.3s ease-in-out',
  minWidth: '48px',
  height: '48px',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  '& svg': {
    width: '24px',
    height: '24px',
  },
});



// ... rest of the component remains the same ...

function Features() {
  // Split features into two groups of three
  const leftFeatures = features.slice(0, 3);
  const rightFeatures = features.slice(3, 6);

  return (
    <Container maxWidth="lg" sx={{ py: 8 }}>
      <Box textAlign="center" mb={6}>
        <SectionTitle variant="h3" component="h2" gutterBottom>
          App Deploy Features
        </SectionTitle>
        <Typography variant="subtitle1" color="text.secondary" sx={{ mb: 4 }}>
          Streamline your app distribution process with our comprehensive features
        </Typography>
      </Box>

      <Grid container spacing={4} justifyContent="center">
        {/* Left side features */}
        <Grid item xs={12} md={5}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            {leftFeatures.map((feature, index) => (
              <FeatureCard key={index}  className={`animate-block delay-${(index + 1) * 100}`}>
                <Box sx={{ display: 'flex', alignItems: 'flex-start' }}>
                  <IconWrapper className="icon-wrapper">
                    {icons[feature.icon]}
                  </IconWrapper>
                  <Box sx={{ ml: 2, flex: 1 }}>
                    <Typography variant="h6" component="h3" gutterBottom sx={{ 
                      fontWeight: 600,
                      mb: 1 
                    }}>
                      {feature.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {feature.description}
                    </Typography>
                  </Box>
                </Box>
              </FeatureCard>
            ))}
          </Box>
        </Grid>

        {/* Right side features */}
        <Grid item xs={12} md={5}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            {rightFeatures.map((feature, index) => (
              <FeatureCard key={index}  className={`animate-block delay-${(index + 4) * 100}`}>
                <Box sx={{ display: 'flex', alignItems: 'flex-start' }}>
                  <IconWrapper className="icon-wrapper">
                    {icons[feature.icon]}
                  </IconWrapper>
                  <Box sx={{ ml: 2, flex: 1 }}>
                    <Typography variant="h6" component="h3" gutterBottom sx={{ 
                      fontWeight: 600,
                      mb: 1 
                    }}>
                      {feature.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {feature.description}
                    </Typography>
                  </Box>
                </Box>
              </FeatureCard>
            ))}
          </Box>
        </Grid>
      </Grid>
    </Container>
  );
}

export default Features;
