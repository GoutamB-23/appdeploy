// src/components/Navbar/Navbar.js
import React, { useState, useEffect, useRef } from 'react';
import { animated, useSpring } from '@react-spring/web';
import { AppBar, Toolbar, Typography } from '@mui/material';
import { styled } from '@mui/system';
import FloatingBoard from '../FloatingBoard';
// import './NavBar.css'
import './NavBar.css'

const BUTTON_SIZE = 56;

// Custom Icons Components
const MenuIcon = () => (
  <svg 
    width="24" 
    height="24" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
  >
    <line x1="3" y1="12" x2="21" y2="12" />
    <line x1="3" y1="6" x2="16" y2="6" />
    <line x1="3" y1="18" x2="18" y2="18" />
  </svg>
);
const CloseIcon = () => (
  <svg 
    width="24" 
    height="24" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
  >
    <line x1="18" y1="6" x2="6" y2="18"/>
    <line x1="6" y1="6" x2="18" y2="18"/>
  </svg>
);


const ScrambleTextContainer = styled('div')({
  '& .scramble-text': {
    fontFamily: '"Inter", sans-serif',
    fontSize: '32px',
    fontWeight: 700,
    color: '#1a1a1a',
    letterSpacing: '-0.5px',
     background: 'linear-gradient(45deg,rgb(79, 155, 218), #21CBF3, #2196F3)',
    backgroundSize: '200% auto',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
    animation: 'gradient 3s linear infinite',
  },
  '& .text-scramble-effect': {
    background: 'linear-gradient(45deg,rgb(245, 5, 5),rgb(4, 48, 245),rgb(210, 248, 71))',
    backgroundSize: '200% auto',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
    fontWeight: 800,
    display: 'inline-block',
    animation: 'gradient 2s linear infinite, glitch 0.2s ease-in-out infinite alternate',
  },
  '@keyframes gradient': {
    '0%': {
      backgroundPosition: '0% center',
    },
    '50%': {
      backgroundPosition: '100% center',
    },
    '100%': {
      backgroundPosition: '0% center',
    },
  },
  '@keyframes glitch': {
    '0%': {
      transform: 'skewX(0deg) translateX(0)',
      opacity: 1,
    },
    '100%': {
      transform: 'skewX(2deg) translateX(2px)',
      opacity: 0.8,
    },
  },
});

// Text Scramble Class
class TextScramble {
  constructor(el) {
    this.el = el;
     this.chars = '!<>-_\\/[]{}—=+*^?#░▒▓█├┤┌┐└┘∆≈~';
    this.update = this.update.bind(this);
  }

  setText(newText) {
    const oldText = this.el.innerText;
    const length = Math.max(oldText.length, newText.length);
    const promise = new Promise((resolve) => this.resolve = resolve);
    this.queue = [];
    
    for (let i = 0; i < length; i++) {
      const from = oldText[i] || '';
      const to = newText[i] || '';
      const start = Math.floor(Math.random() * 40);
      const end = start + Math.floor(Math.random() * 40);
      this.queue.push({ from, to, start, end });
    }

    cancelAnimationFrame(this.frameRequest);
    this.frame = 0;
    this.update();
    return promise;
  }

  update() {
    let output = '';
    let complete = 0;

    for (let i = 0, n = this.queue.length; i < n; i++) {
      let { from, to, start, end, char } = this.queue[i];

      if (this.frame >= end) {
        complete++;
        output += to;
      } else if (this.frame >= start) {
        if (!char || Math.random() < 0.28) {
          char = this.randomChar();
          this.queue[i].char = char;
        }
        output += `<span class="text-scramble-effect">${char}</span>`;
      } else {
        output += from;
      }
    }

    this.el.innerHTML = output;

    if (complete === this.queue.length) {
      this.resolve();
    } else {
      this.frameRequest = requestAnimationFrame(this.update);
      this.frame++;
    }
  }

  randomChar() {
    return this.chars[Math.floor(Math.random() * this.chars.length)];
  }
}

function Navbar() {
  const [isFloatingOpen, setFloatingOpen] = useState(false);
  const [buttonPosition, setButtonPosition] = useState({ top: 0, left: 0 });
  const buttonRef = useRef(null);

  const textRef = useRef(null);
  const scrambleRef = useRef(null);

  const [{ opacity }, api] = useSpring(
    () => ({
      opacity: 0,
    }),
    []
  );

   useEffect(() => {
    if (textRef.current && !scrambleRef.current) {
      scrambleRef.current = new TextScramble(textRef.current);
      scrambleRef.current.setText('App Deploy');
    }

    // Trigger the effect every 7 seconds
    const interval = setInterval(() => {
      if (scrambleRef.current) {
        scrambleRef.current.setText('App Deploy');
      }
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const updatePosition = () => {
      if (buttonRef.current) {
        const rect = buttonRef.current.getBoundingClientRect();
        setButtonPosition({
          top: rect.bottom + 10,
          left: rect.left
        });
      }
    };

    updatePosition();
    window.addEventListener('resize', updatePosition);
    return () => window.removeEventListener('resize', updatePosition);
  }, []);

  const handleButtonClick = () => {
    setFloatingOpen(prev => !prev);
    api.start({
      opacity: !isFloatingOpen ? 1 : 0
    });
  };

  return (
    <>
      <AppBar   position="static"
  sx={{ 
    background: 'linear-gradient(to right, rgba(255,255,255,0.95), rgba(255,255,255,0.98))',
    borderBottom: '1px solid rgba(0, 0, 0, 0.1)',
    boxShadow: '0 2px 12px rgba(0,0,0,0.05)'
  }}>
        <Toolbar sx={{ justifyContent: 'space-between' }}>
          {/* App Deploy Text with Animation */}
           {/* <Typography
            variant="h5"
            sx={{
              fontFamily: '"Inter", sans-serif', // More professional font
              fontSize: '24px',
              fontWeight: 600,
              color: '#1a1a1a',
              letterSpacing: '-0.5px',
              opacity: 0,
              animation: 'fadeIn 0.5s ease-out forwards',
              '@keyframes fadeIn': {
                from: { 
                  opacity: 0, 
                  transform: 'translateY(-10px)' 
                },
                to: { 
                  opacity: 1, 
                  transform: 'translateY(0)' 
                }
              }
            }}
          >
            App Deploy
          </Typography> */}

          <ScrambleTextContainer>
            <div
              ref={textRef}
              className="scramble-text"
            >
              App Deploy
            </div>
          </ScrambleTextContainer>

          {/* Floating Button */}
          <BlurredBackground
            style={{
              backgroundColor: opacity.to(o => `rgba(0,0,0,${0.2 * o})`),
            }}
          >
            <FloatingButton
              ref={buttonRef}
              onClick={handleButtonClick}
              className={isFloatingOpen ? 'active' : ''}
            >
               <span>
                {isFloatingOpen ? <CloseIcon /> : <MenuIcon />}
              </span>
            </FloatingButton>
          </BlurredBackground>
        </Toolbar>
      </AppBar>

      <FloatingBoard 
        isOpen={isFloatingOpen} 
        onClose={() => {
          setFloatingOpen(false);
          api.start({ opacity: 0 });
        }}  
        position={buttonPosition}
        toggleBoard={() => {
          setFloatingOpen(prev => !prev);
          api.start({ opacity: isFloatingOpen ? 0 : 1 });
        }}
      />
    </>
  );
}

const BlurredBackground = styled(animated.div)({
  padding: 12,
  borderRadius: 8,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backdropFilter: 'blur(8px)',
  touchAction: 'none',
});

const FloatingButton = styled(animated.div)({
  width: BUTTON_SIZE,
  height: BUTTON_SIZE,
  borderRadius: '50%',
  border: 'none',
  position: 'relative',
  backgroundClip: 'content-box',
  zIndex: 0,
  touchAction: 'none',
  cursor: 'pointer',
  transition: 'transform 0.3s ease-in-out, background-color 0.3s ease',
  
  '&:hover': {
    transform: 'scale(1.1)',
  },

  '&.active': {
    transform: 'scale(1.1)',
    '& > span': {
      background: 'linear-gradient(45deg, #21CBF3 30%, #2196F3 90%)',
    }
  },

  '& > span': {
    borderRadius: 'inherit',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: '100%',
    backgroundColor: '#fafafa',
    boxShadow: '0 3px 15px rgba(33, 150, 243, 0.3)',
    background: 'linear-gradient(45deg, #2196F3 30%, #21CBF3 90%)',
    
    '& svg': {
      color: '#ffffff',
      transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    },
  },
    '@keyframes pulse': {
    '0%': {
      boxShadow: '0 0 0 0 rgba(33, 150, 243, 0.4)',
    },
    '70%': {
      boxShadow: '0 0 0 10px rgba(33, 150, 243, 0)',
    },
    '100%': {
      boxShadow: '0 0 0 0 rgba(33, 150, 243, 0)',
    },
  },
  
  '&:not(.active):hover > span': {
    animation: 'pulse 1.5s infinite',
  },
});


export default Navbar;
