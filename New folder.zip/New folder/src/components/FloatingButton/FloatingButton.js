// src/components/FloatingButton/FloatingButton.js
import React, { useEffect, useState } from 'react';
import { Button } from '@mui/material';
import ChatIcon from '@mui/icons-material/Chat';
import { useNavigate, useLocation } from 'react-router-dom';
import './FloatingButton.css';

const FloatingButton = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [direction, setDirection] = useState({ dx: 2, dy: 2 });

    useEffect(() => {
        const moveButton = () => {
            setPosition(prev => {
                let newX = prev.x + direction.dx;
                let newY = prev.y + direction.dy;
                let newDx = direction.dx;
                let newDy = direction.dy;

                // Check window boundaries and reverse direction if needed
                if (newX <= 0 || newX >= window.innerWidth - 100) {
                    newDx = -newDx;
                }
                if (newY <= 0 || newY >= window.innerHeight - 100) {
                    newDy = -newDy;
                }

                // Update direction if changed
                if (newDx !== direction.dx || newDy !== direction.dy) {
                    setDirection({ dx: newDx, dy: newDy });
                }

                return {
                    x: newX,
                    y: newY
                };
            });
        };

        const animationFrame = setInterval(moveButton, 50);
        return () => clearInterval(animationFrame);
    }, [direction]);

    const handleClick = () => {
        navigate('/chatbot');
    };

    // Hide button on chatbot page - moved after hooks
    if (location.pathname === '/chatbot') {
        return null;
    }

    return (
        <Button
            className="floating-button"
            variant="contained"
            onClick={handleClick}
            style={{
                position: 'fixed',
                left: `${position.x}px`,
                top: `${position.y}px`,
                zIndex: 9999,
                transition: 'transform 0.3s ease-in-out'
            }}
            sx={{
                width: '60px',
                height: '60px',
                borderRadius: '50%',
                minWidth: 'unset',
                padding: 0,
                background: 'linear-gradient(45deg, #2196F3 30%, #21CBF3 90%)',
                boxShadow: '0 3px 15px rgba(33, 150, 243, 0.3)',
                '&:hover': {
                    transform: 'scale(1.1)',
                    background: 'linear-gradient(45deg, #21CBF3 30%, #2196F3 90%)',
                    boxShadow: '0 5px 20px rgba(33, 150, 243, 0.4)',
                }
            }}
        >
            <ChatIcon />
        </Button>
    );
};

export default FloatingButton;
