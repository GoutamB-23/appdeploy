﻿using AppDeploy.Entities;
using AppDeploy.Services;
using CloudinaryDotNet;
using CloudinaryDotNet.Actions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using QRCoder;
using System;
using System.IO.Compression;

namespace AppDeploy.Controllers;

[Route("api/[controller]")]
[ApiController]
public class AppsController : ControllerBase
{
    private readonly S3StorageService _storageService;

    public AppsController(S3StorageService storageService)
    {
        _storageService = storageService;
    }

    [HttpPost("upload-apk")]
    public async Task<IActionResult> UploadApk(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest("File is required.");

        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (ext != ".apk" && ext != ".zip")
            return BadRequest("Only .apk or .zip files are supported.");

        //var fileKey = await _storageService.UploadFileAsync(file);
        //var url = _storageService.GetPresignedUrl(fileKey, TimeSpan.FromDays(1));

        //// Generate QR Code
        //using var qrGenerator = new QRCodeGenerator();
        //var qrData = qrGenerator.CreateQrCode(url, QRCodeGenerator.ECCLevel.Q);
        //var qrCode = new Base64QRCode(qrData);
        //var qrCodeImage = qrCode.GetGraphic(20);

        //return Ok(new
        //{
        //    downloadUrl = url,
        //    qrCodeBase64 = $"data:image/png;base64,{qrCodeImage}"
        //});

        try
        {
            var (url, qrBytes) = await _storageService.UploadAndGenerateQrAsync(file);
            var base64Qr = Convert.ToBase64String(qrBytes);

            // Get appropriate URL (same method was used inside UploadAndGenerateQrAsync)

            return Ok(new
            {
                downloadUrl = url,
                qrCodeBase64 = $"data:image/png;base64,{base64Qr}"
            });
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Upload failed: {ex.Message}");
        }
    }

    [HttpPost("cleanup")]
    public async Task<IActionResult> CleanupOldFiles()
    {
        await _storageService.CleanupOldFilesAsync();
        return Ok("Old files cleaned up successfully.");
    }


}
