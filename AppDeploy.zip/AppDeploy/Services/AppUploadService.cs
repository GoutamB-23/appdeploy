﻿using Amazon.S3;
using Amazon.S3.Model;
using AppDeploy.Interface;

namespace AppDeploy.Services;

public class AppUploadService : IAppUploadService
{
    private readonly IAmazonS3 _s3Client;
    private readonly string _bucketName;
    private readonly IWebHostEnvironment _env;

    public AppUploadService(IAmazonS3 s3Client, IConfiguration config, IWebHostEnvironment env)
    {
        _s3Client = s3Client;
        _bucketName = config["AWS:ZipBucket"];
        _env = env;
    }

    public async Task<byte> UploadAndGenerateQrAsync(IFormFile file)
    {
        if (file == null || file.Length == 0) throw new ArgumentNullException("No file uploaded");

        var ext = Path.GetExtension(file.FileName).ToLower();

        if (ext == ".apk")
            return await UploadApkAsync(file);
        else if (ext == ".zip")
            return await UploadWebAppZipAsync(file);
        else
            throw new ArgumentException("Only supports .apk and .zip files");
    }

    private async Task<byte> UploadWebAppZipAsync(IFormFile file)
    {
        var apkBucket = _bucketName;
        var key = $"apk/{Guid.NewGuid()}_{file.FileName}";

        using var stream = file.OpenReadStream();
        var request = new PutObjectRequest
        {
            BucketName = apkBucket,
            Key = key,
            InputStream = stream,
            ContentType = "application/vnd.android.package-archive"
        };
        await _s3Client.PutObjectAsync(request);

        var url = $"https://{apkBucket}.s3.amazonaws.com/{key}";
        return GenerateQr(url);
    }

    private async Task<byte> UploadApkAsync(IFormFile file)
    {
        throw new NotImplementedException();
    }


    private byte GenerateQr(string url)
    {
        throw new NotImplementedException();
    }
}
