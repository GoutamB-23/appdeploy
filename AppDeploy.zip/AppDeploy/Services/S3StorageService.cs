﻿using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using QRCoder;
using System.IO.Compression;

namespace AppDeploy.Services;

public class S3StorageService
{
    private readonly IAmazonS3 _s3Client;
    public readonly string _bucketName = "appdeploy-webapps";
    public readonly string _region;

    public S3StorageService(IAmazonS3 s3Client, IConfiguration config)
    {
        _s3Client = s3Client;
        _region = config["AWS:Region"];
    }

    public async Task<string> UploadFileAsync(IFormFile file)
    {
        var fileKey = $"app-{Guid.NewGuid()}/{file.FileName}";

        using var stream = file.OpenReadStream();
        var uploadRequest = new TransferUtilityUploadRequest
        {
            InputStream = stream,
            Key = fileKey,
            BucketName = _bucketName,
            ContentType = file.ContentType
        };

        var transferUtility = new TransferUtility(_s3Client);
        await transferUtility.UploadAsync(uploadRequest);

        return fileKey;
    }

    public async Task<(string url, byte[] qrCodeBytes)> UploadAndGenerateQrAsync(IFormFile file)
    {
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();

        string url;

        if (ext == ".apk")
        {
            // Direct upload to S3
            var fileKey = await UploadFileAsync(file);
            url = GetPresignedUrl(fileKey, TimeSpan.FromDays(7));
        }
        else if (ext == ".zip")
        {
            // Extract ZIP and upload contents
            var folderName = $"webapp-{Guid.NewGuid()}";
            var tempRoot = Path.Combine(Path.GetTempPath(), "AppDeployTemp");
            var tempPath = Path.Combine(Path.GetTempPath(), folderName);

            Directory.CreateDirectory(tempPath);

            var zipPath = Path.Combine(tempPath, file.FileName);
            using (var fs = new FileStream(zipPath, FileMode.Create))
                await file.CopyToAsync(fs);

            ZipFile.ExtractToDirectory(zipPath, tempPath);

            var transfer = new TransferUtility(_s3Client);
            var allFiles = Directory.GetFiles(tempPath, "*.*", SearchOption.AllDirectories);
            //await transfer.UploadDirectoryAsync(
            //    directory: tempPath,
            //    bucketName: _bucketName,
            //    searchPattern: "*.*",
            //    searchOption: SearchOption.AllDirectories
            //);

            foreach (var filePath in allFiles)
            {
                //var relativePath = Path.GetRelativePath(tempPath, filePath).Replace("\\", "/");
                var key = folderName + "/" + Path.GetRelativePath(tempPath, filePath).Replace("\\","/");

                var uploadRequest = new TransferUtilityUploadRequest
                {
                    FilePath = filePath,
                    Key = key,
                    BucketName = _bucketName,
                    ContentType = GetMimeType(filePath)
                };

                await transfer.UploadAsync(uploadRequest);
            }

            

            // Static S3 site URL
            // Find the first index.html in the extracted files
            //var indexFile = allFiles
            //    .FirstOrDefault(f => string.Equals(Path.GetFileName(f), "index.html", StringComparison.OrdinalIgnoreCase));

            //if (indexFile == null)
            //    throw new FileNotFoundException("index.html not found in the uploaded zip file.");

            // Detect project type
            //var projectType = DetectProjectType(tempPath);

            //// Determine index.html path
            //string indexRelativePath = projectType switch
            //{
            //    ProjectType.React => "build/index.html",
            //    ProjectType.Vue => "dist/index.html",
            //    ProjectType.Angular => "index.html", // usually Angular outputs to root unless customized
            //    ProjectType.StaticHtml => "index.html",
            //    _ => "index.html"
            //};

            // Detect project type and determine index.html path
            var projectType = DetectProjectType(tempPath);
            string buildFolder = projectType switch
            {
                ProjectType.React => "build",
                ProjectType.Vue => "dist",
                ProjectType.Angular => "", // usually outputs to root
                ProjectType.StaticHtml => "",
                _ => ""
            };

            string fullIndexPath = string.IsNullOrEmpty(buildFolder)
                ? Path.Combine(tempPath, Path.GetFileNameWithoutExtension(file.FileName),"index.html")
                : Path.Combine(tempPath, Path.GetFileNameWithoutExtension(file.FileName), buildFolder, "index.html");

            if (!File.Exists(fullIndexPath))
            {
                // fallback: try root/index.html if not in expected subfolder
                fullIndexPath = Path.Combine(tempPath, "index.html");

                if (!File.Exists(fullIndexPath))
                    throw new FileNotFoundException("index.html not found in expected build directories.");
            }

            string indexRelativePath = Path.GetRelativePath(tempPath, fullIndexPath).Replace("\\", "/");


            // Get the relative path to index.html for the S3 URL
            //var indexRelativePath = Path.GetRelativePath(tempPath, indexFile).Replace("\\", "/");
            url = $"http://{_bucketName}.s3-website.{_region}.amazonaws.com/{folderName}/{indexRelativePath}";
            Directory.Delete(tempPath, true);
        }
        else
        {
            throw new ArgumentException("Unsupported file format");
        }

        // Generate QR Code
        using var qrGen = new QRCodeGenerator();
        var qrData = qrGen.CreateQrCode(url, QRCodeGenerator.ECCLevel.Q);
        using var qrPng = new PngByteQRCode(qrData);
        var qrBytes = qrPng.GetGraphic(20);

        return (url, qrBytes);
    }

    public string GetPresignedUrl(string fileKey, TimeSpan expiry)
    {
        var request = new GetPreSignedUrlRequest
        {
            BucketName = _bucketName,
            Key = fileKey,
            Expires = DateTime.UtcNow.Add(expiry)
        };

        return _s3Client.GetPreSignedURL(request);
    }

    public async Task CleanupOldFilesAsync(int olderThanHours = 24)
    {
        var listRequest = new ListObjectsV2Request
        {
            BucketName = _bucketName
        };

        var listResponse = await _s3Client.ListObjectsV2Async(listRequest);
        var now = DateTime.UtcNow;

        foreach (var obj in listResponse.S3Objects)
        {
            if (obj.LastModified.HasValue &&
                (now - obj.LastModified.Value.ToUniversalTime()).TotalHours > olderThanHours)
            {
                await _s3Client.DeleteObjectAsync(_bucketName, obj.Key);
            }
        }
    }
    private string GetMimeType(string filePath)
    {
        var ext = Path.GetExtension(filePath).ToLowerInvariant();
        return ext switch
        {
            ".html" => "text/html",
            ".js" => "application/javascript",
            ".css" => "text/css",
            ".json" => "application/json",
            ".png" => "image/png",
            ".jpg" => "image/jpeg",
            ".jpeg" => "image/jpeg",
            ".svg" => "image/svg+xml",
            ".woff" => "font/woff",
            ".woff2" => "font/woff2",
            ".ttf" => "font/ttf",
            _ => "application/octet-stream"
        };
    }

    private ProjectType DetectProjectType(string extractedFolder)
    {
        var files = Directory.GetFiles(extractedFolder, "*.*", SearchOption.AllDirectories);

        bool Has(string file) => files.Any(f => f.EndsWith(file, StringComparison.OrdinalIgnoreCase));
        bool HasInPath(string keyword) => files.Any(f => f.Contains(keyword, StringComparison.OrdinalIgnoreCase));

        if (Has("manifest.json") && HasInPath("static"))
            return ProjectType.React;

        if (Has("main.js") && Has("polyfills.js"))
            return ProjectType.Angular;

        if (Has("chunk-vendors.js") || HasInPath("dist"))
            return ProjectType.Vue;

        if (Has("index.html"))
            return ProjectType.StaticHtml;

        return ProjectType.Unknown;
    }

    public class ProjectInfo
    {
        public ProjectType ProjectType { get; set; }
        public bool IsBuilt { get; set; }
        public string? BuildFolder { get; set; }
    }

    public enum ProjectType
    {
        Unknown,
        StaticHtml,
        React,
        Angular,
        Vue
    }
}
