﻿namespace AppDeploy.Interface;

public interface IAppUploadService
{
    public Task<byte> UploadAndGenerateQrAsync(IFormFile file);
}
