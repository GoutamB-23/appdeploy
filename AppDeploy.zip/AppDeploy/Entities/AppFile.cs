﻿namespace AppDeploy.Entities;

internal class AppFile
{
    public string FileName { get; set; }
    public string FilePath { get; set; }
    public string DownloadUrl { get; set; }
    public int DownloadCount { get; set; }
    public DateTime UploadedAt { get; set; }
}