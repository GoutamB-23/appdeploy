﻿namespace AppDeploy.Entities;

public class FileUploadInfo
{
    public string FileKey { get; set; }
    public string Password { get; set; }
}
