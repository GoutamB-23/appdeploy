﻿using AppDeploy.Services;
using Amazon.S3;
using Amazon.Runtime;
using Amazon;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Load AWS settings from appsettings.json
var awsOptions = builder.Configuration.GetSection("AWS");
string accessKey = awsOptions["AccessKey"];
string secretKey = awsOptions["SecretKey"];
string region = awsOptions["Region"];
string bucketName = awsOptions["BucketName"];

// Manually set AWS credentials
var awsCredentials = new BasicAWSCredentials(accessKey, secretKey);
var s3Client = new AmazonS3Client(awsCredentials, RegionEndpoint.GetBySystemName(region));

// AWS S3 Configuration
builder.Services.AddSingleton<IAmazonS3>(s3Client);
builder.Services.AddSingleton<S3StorageService>();

builder.Services.AddControllers();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "AppDeploy API", Version = "v1" });

});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
