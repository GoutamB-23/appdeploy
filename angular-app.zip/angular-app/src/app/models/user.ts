export interface User {
    userID: string;
    personName: string;
    email: string;
    password: string;
    gender: string;
}
