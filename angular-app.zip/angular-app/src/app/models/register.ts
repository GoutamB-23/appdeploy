export interface Register {
    personName: string;
    email: string;
    password: string;
    gender: string;
}
