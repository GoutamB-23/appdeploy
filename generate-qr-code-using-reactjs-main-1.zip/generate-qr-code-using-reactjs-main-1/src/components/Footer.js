function Footer() {
   return (
      <footer className="attribution">
         <p>developed by <a href="https://github.com/thamerh" target="_blank" rel="noreferrer">Thamer Hamdi</a></p>
      </footer>
   );
}

export default Footer;
